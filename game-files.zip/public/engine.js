export const WIDTH=640, HEIGHT=400, STEP=8;
export const overlaps=(a,b)=>a[0]<b[0]+b[2]&&a[0]+a[2]>b[0]&&a[1]<b[1]+b[3]&&a[1]+a[3]>b[1];
export const feet=(x,y)=>[x-5,y-4,10,8];
export function blocked(x,y,collisions){return x<6||x>WIDTH-6||y<5||y>HEIGHT-5||collisions.some(c=>overlaps(feet(x,y),c));}
export function distanceToRect(x,y,r){return Math.hypot(Math.max(r[0]-x,0,x-r[0]-r[2]),Math.max(r[1]-y,0,y-r[1]-r[3]));}
export function findPath(start,goal,collisions){
 const cols=WIDTH/STEP,rows=HEIGHT/STEP,key=(x,y)=>y*cols+x,cell=([x,y])=>[Math.floor(x/STEP),Math.floor(y/STEP)],world=(x,y)=>[x*STEP+4,y*STEP+4];
 let [sx,sy]=cell(start),[gx,gy]=cell(goal);gx=Math.max(0,Math.min(cols-1,gx));gy=Math.max(0,Math.min(rows-1,gy));const q=[[sx,sy]],seen=new Map([[key(sx,sy),null]]);let best=[sx,sy],bestD=Infinity;
 for(let head=0;head<q.length;head++){
  const [x,y]=q[head],d=(x-gx)**2+(y-gy)**2;if(d<bestD){bestD=d;best=[x,y]}if(d===0)break;
  for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=key(nx,ny);if(nx<0||ny<0||nx>=cols||ny>=rows||seen.has(k)||blocked(...world(nx,ny),collisions))continue;seen.set(k,[x,y]);q.push([nx,ny]);}
 }
 const path=[];let cur=best;while(cur&&(cur[0]!==sx||cur[1]!==sy)){path.unshift(world(...cur));cur=seen.get(key(...cur));}return path;
}
export function placementValid(rect,collisions,player,exits=[]){return rect[0]>=16&&rect[1]>=80&&rect[0]+rect[2]<=624&&rect[1]+rect[3]<=384&&!collisions.some(c=>overlaps(rect,c))&&!overlaps(rect,feet(player.x,player.y))&&!exits.some(e=>overlaps(rect,e.rect));}
// Find the nearest reachable interaction position in one search, rather than guessing four sides.
export function findApproachPath(start,rect,collisions,reach=38){
 if(!blocked(...start,collisions)&&distanceToRect(...start,rect)<=reach)return [];
 const cols=WIDTH/STEP,rows=HEIGHT/STEP,key=(x,y)=>y*cols+x,world=(x,y)=>[x*STEP+4,y*STEP+4];
 const sx=Math.floor(start[0]/STEP),sy=Math.floor(start[1]/STEP),queue=[[sx,sy]],parents=new Map([[key(sx,sy),null]]);let goal=null;
 for(let i=0;i<queue.length;i++){
  const [x,y]=queue[i],point=world(x,y);if(!blocked(...point,collisions)&&distanceToRect(...point,rect)<=reach){goal=[x,y];break}
  for(const [dx,dy]of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,k=key(nx,ny);if(nx<0||ny<0||nx>=cols||ny>=rows||parents.has(k)||blocked(...world(nx,ny),collisions))continue;parents.set(k,[x,y]);queue.push([nx,ny])}
 }
 if(!goal)return null;const route=[];for(let cur=goal;cur&&(cur[0]!==sx||cur[1]!==sy);cur=parents.get(key(...cur)))route.unshift(world(...cur));return route;
}
