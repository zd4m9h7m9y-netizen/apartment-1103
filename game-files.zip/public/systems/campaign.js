import {generateRound,shuffleForRound} from './rounds.js';
export const RULESET='apartment1103-three-chains-v1';
export const CHAIN_NAMES={A:'邀请卡线',B:'城市明信片线',C:'留言图标线'};
export const SYMBOLS=['月亮','窗户','星星'];
const permutations=['012','021','102','120','201','210'];
export function createCampaignRound(previous=null,seed){return generateRound({seed,number:(previous?.number||0)+1,previous,ruleset:RULESET,slots:[{id:'chain',options:['A','B','C']},{id:'musicOrder',options:permutations},{id:'washer',options:['0','1','2']},{id:'basket',options:['left','right']},{id:'direction',options:['left','right']},{id:'position',options:['one','two']}]})}
export function buildCampaign(round){
 const chain=round.choices.chain;if(!CHAIN_NAMES[chain])throw Error('Unknown campaign chain');
 const firstOrder=[...round.choices.musicOrder].map(i=>SYMBOLS[Number(i)]),direction=round.choices.direction==='left'?'从左到右':'从右到左',bookOrder=direction==='从左到右'?firstOrder:[...firstOrder].reverse();
 const finalOrder=shuffleForRound(SYMBOLS,round,'roof-order'),code=shuffleForRound(['0','1','2','3','4','5','6','7','8','9'],round,'postcard-code').slice(0,4).join('');
 const rightBasket=round.choices.basket==='right',basketId=rightBasket?'laundry_room.basket.10':'laundry_room.basket.9',basketPosition=rightBasket?[352,248]:[208,256],washerId='laundry.washer.'+round.choices.washer;
 const defs={revision:RULESET,items:{},pickups:{},recipes:[],uses:[],mechanisms:{},areas:{rooftop:{requires:{flag:'rooftopReady'}},birthday_party:{requires:{flag:'rooftopReady'}}}};
 const placements=[],bindings={},descriptions={};
 const item=(id,name,description)=>defs.items[id]={name,description,icon:`assets/campaign/${id}.png`};
 const place=(scene,id,asset,x,y,eventId,label,extra={})=>placements.push({scene,id,asset,x,y,width:32,height:32,eventId,label,collider:null,draggable:false,layer:'world',...extra});
 const bind=(id,config)=>bindings[id]=config;
 const unlock={flags:{rooftopReady:true},unlock:['rooftop','birthday_party']};
 if(chain==='A'){
  item('invite_left','邀请卡 · 左半','从唱片架收纳格里找到。撕开的边缘还缺另一半。');item('laundry_ticket','洗衣取件卡',`对应洗衣机 ${Number(round.choices.washer)+1} 号。拿好后点击对应设备确认取件。`);item('invite_right','邀请卡 · 右半','从折叠台旁布袋里取出，可以和左半组合。');item('invitation','完整邀请卡','两半已经拼好。R · 1103。拿在手上，在电梯右侧面板出示。');
  defs.mechanisms['music.sequence']={type:'sequence',label:'唱片架 · 封套收纳',prompt:'参考旁边的目录卡，依次选择图形。',tokens:SYMBOLS,answer:firstOrder,effects:{grant:{invite_left:1}}};
  bind('apartment_4b.record_player.7',{mechanismId:'music.sequence',label:'唱片架 · 封套收纳'});
  place('apartment_4b','music.directory','directory',304,144,'campaign.directory','唱片目录卡');descriptions['music.directory']=`收纳目录：${firstOrder.join(' → ')}。`;
  place('apartment_4b','a.ticket','ticket',412,274,'campaign.pickup','洗衣取件卡',{depth:321});defs.pickups['a.ticket']={item:'laundry_ticket'};
  defs.uses.push({id:'laundry.confirm',item:'laundry_ticket',target:washerId,consume:1,effects:{flags:{laundryReleased:true}}});
  defs.mechanisms['laundry.basket']={type:'drag',origin:basketPosition,distance:32,effects:{flags:{basketMoved:true}}};bind(basketId,{mechanismId:'laundry.basket',label:'可挪开的洗衣篮'});
  place('laundry_room','a.pouch','pouch',...basketPosition,'campaign.pickup','露出的布袋');defs.pickups['a.pouch']={item:'invite_right',requires:{all:[{flag:'basketMoved'},{flag:'laundryReleased'}]}};
  defs.recipes.push({id:'join.invitation',inputs:['invite_left','invite_right'],effects:{grant:{invitation:1},flags:{mainClueReady:true}}});defs.uses.push({id:'roof.invitation',item:'invitation',target:'elevator.elevator_panel.1',effects:unlock});
 }else if(chain==='B'){
  item('postcard_left','城市明信片 · 左半','从床头柜里找到的纽约夜景明信片。不是那张生日纪念合照。');item('postcard_right','城市明信片 · 右半','洗衣房收纳夹附近找到的另一半夜景。');item('postcard','完整城市明信片',`背面四个窗格由左至右标着：${[...code].join(' · ')}。R 层面板也有四个输入位置。`);
  defs.pickups['apartment_4b.drawer.12']={item:'postcard_left'};bind('apartment_4b.drawer.12',{label:'床头柜 · 城市明信片',container:true});
  defs.mechanisms['laundry.basket']={type:'drag',origin:basketPosition,distance:32,effects:{flags:{basketMoved:true}}};bind(basketId,{mechanismId:'laundry.basket',label:'可挪开的洗衣篮'});
  place('laundry_room','b.postcard','postcard_right',...basketPosition,'campaign.pickup','明信片的另一半');defs.pickups['b.postcard']={item:'postcard_right',requires:{flag:'basketMoved'}};
  bind('laundry_room.noticeboard.15',{label:'失物招领 · 照片收纳夹',description:'照片收纳夹上写着：另一半暂放在折叠台旁。那里有一个篮子挡住了。'});
  defs.recipes.push({id:'join.postcard',inputs:['postcard_left','postcard_right'],effects:{grant:{postcard:1},flags:{mainClueReady:true}}});
  defs.mechanisms['roof.code']={type:'code',label:'R · 四个窗格',prompt:'查看拼好的明信片背面，由左至右输入四个数字。',inputMode:'numeric',answer:code,requires:{item:'postcard'},effects:unlock};
  bind('elevator.elevator_panel.1',{mechanismId:'roof.code',label:'电梯面板 · R'});defs.uses.push({id:'roof.readPostcard',item:'postcard',target:'elevator.elevator_panel.1',effects:{}});
 }else{
  item('icon_guide','图标说明卡',`三个图标：${firstOrder.join(' · ')}。阅读方向：${direction}。对照书架上的三个标签。`);item('message_card','展开的留言卡','折叠处的图标指向 Apartment 4C 公共茶几上的收纳盒。拿好这张卡，对收纳盒使用。');item('sequence_card','最终顺序卡',`R · ${finalOrder.join(' → ')}。按这个顺序操作电梯面板。`);
  defs.pickups['hallway.noticeboard.5']={item:'icon_guide'};
  // The existing hallway board ID is matched by asset/event when maps are patched below.
  defs.mechanisms['book.sequence']={type:'sequence',label:'书架 · 折叠留言',prompt:'对照说明卡中的图标及阅读方向，依次选择。',tokens:SYMBOLS,answer:bookOrder,requires:{item:'icon_guide'},effects:{grant:{message_card:1}}};bind('apartment_4b.bookshelf.8',{mechanismId:'book.sequence',label:'书架 · 折叠留言'});
  place('apartment_4c','c.publicBox','keepsake_box',240,272,'campaign.box','公共桌旁的收纳盒');defs.uses.push({id:'open.publicBox',item:'message_card',target:'c.publicBox',effects:{grant:{sequence_card:1},flags:{mainClueReady:true}}});
  defs.mechanisms['roof.sequence']={type:'sequence',label:'R · 图标面板',prompt:'按最终顺序卡选择图标。',tokens:SYMBOLS,answer:finalOrder,requires:{item:'sequence_card'},effects:unlock};bind('elevator.elevator_panel.1',{mechanismId:'roof.sequence',label:'电梯面板 · R'});defs.uses.push({id:'roof.readSequence',item:'sequence_card',target:'elevator.elevator_panel.1',effects:{}});
 }
 // Resolve existing IDs explicitly during patching; keep target/use rules synchronized.
 function patch(maps){
  const panel=maps.elevator.objects.find(o=>o.eventId==='elevator_panel');if(!panel)throw Error('Elevator panel missing');
  const oldPanel='elevator.elevator_panel.1';if(panel.id!==oldPanel){for(const u of defs.uses)if(u.target===oldPanel)u.target=panel.id;if(bindings[oldPanel]){bindings[panel.id]=bindings[oldPanel];delete bindings[oldPanel]}}
  if(chain==='C'){const board=maps.hallway.objects.find(o=>o.eventId==='notice');const old='hallway.noticeboard.5';if(board.id!==old){defs.pickups[board.id]=defs.pickups[old];delete defs.pickups[old]}bind(board.id,{container:true,label:'公告板 · 图标说明卡'})}
  for(const map of Object.values(maps))for(const o of map.objects){const b=bindings[o.id];if(b)Object.assign(o,b);if(defs.pickups[o.id]&&!placements.some(p=>p.id===o.id))o.container=true;}
  for(const obj of placements)maps[obj.scene].objects.push({...obj,pickupSprite:!!defs.pickups[obj.id]});
 }
 function hint(system,level=1){
  if(system.state.flags.rooftopReady)return'天台已经开放。回电梯选择 R 层。';
  if(chain==='A'){
   if(!system.state.completed.includes('mechanism:music.sequence'))return level<2?'唱片架旁的目录卡似乎有顺序。':`目录卡的顺序是：${firstOrder.join(' → ')}。点击唱片架依次操作。`;
   if(!system.state.claimed.includes('a.ticket')&&!system.state.flags.laundryReleased)return'学习桌的待办夹里有洗衣取件卡。拿好后在对应的洗衣机使用。';
   if(!system.state.flags.laundryReleased)return`取件卡对应洗衣机 ${Number(round.choices.washer)+1} 号。先从口袋拿好取件卡。`;
   if(!system.state.flags.basketMoved)return'折叠台旁的篮子挡住了布袋。走近后把带标记的篮子拖开。';
   if(!system.count('invite_right')&&!system.count('invitation'))return'篮子挪开后，还需要点击露出的布袋取出右半。';
   if(!system.count('invitation'))return'打开口袋，选择邀请卡的左右两半，再点击组合。';return'从口袋拿好完整邀请卡，在电梯右侧面板出示。';
  }
  if(chain==='B'){
   if(!system.state.claimed.includes('apartment_4b.drawer.12'))return'看看卧室床头柜。';if(!system.state.flags.basketMoved)return'洗衣房失物区的收纳夹，指向折叠台旁可挪开的篮子。';if(!system.count('postcard')&&!system.count('postcard_right'))return'点击篮子下面露出的明信片。';if(!system.count('postcard'))return'在口袋组合明信片的两半。';return level<2?'看看完整明信片背面的窗格，再操作 R 面板。':`本轮窗格由左至右是 ${code}。在电梯 R 面板输入。`;
  }
  if(!system.count('icon_guide'))return'走廊公告板上有图标说明卡。';if(!system.count('message_card'))return level<2?'书架标签与说明卡上的图标相同，注意阅读方向。':`书架操作顺序：${bookOrder.join(' → ')}。`;if(!system.count('sequence_card'))return'拿好展开的留言卡，对 4C 公共桌旁的收纳盒使用。';return level<2?'最终顺序卡对应电梯 R 面板的图标。':`R 面板操作顺序：${finalOrder.join(' → ')}。`;
 }
 return{round,chain,defs,bindings,placements,descriptions,patch,hint,params:{firstOrder,bookOrder,finalOrder,code,basketId,basketPosition,washerId}};
}
