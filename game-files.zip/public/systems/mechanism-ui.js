export function createMechanismUI({system,notify,onOpen,onClose,onSolved}){
 const $=s=>document.querySelector(s),dialog=$('#mechanism-dialog'),body=$('#mechanism-controls');
 function open(id){const m=system.defs.mechanisms[id];if(!m)return;onOpen?.();$('#mechanism-title').textContent=m.label||'机关';$('#mechanism-feedback').textContent='';body.replaceChildren();if(m.prompt){const p=document.createElement('p');p.textContent=m.prompt;body.append(p)}
  function attempt(value){const r=system.operate(id,value);$('#mechanism-feedback').textContent=r.ok?(r.already?'这个机关已经完成。':'机关操作成功。'):({'incorrect':'暂时没有反应，请检查输入。','wrong-order':'顺序不对，可以重新尝试。','in-progress':'这一项正确，继续下一项。','conditions':'还需要满足其他条件。'}[r.reason]||'暂时无法操作。');if(r.ok){notify('机关完成，新状态已保存。');for(const button of body.querySelectorAll('button'))button.disabled=true;if(!r.already)onSolved?.(id)}}
  if(system.state.completed.includes('mechanism:'+id)){$('#mechanism-feedback').textContent='这个机关已经完成。';return dialog.showModal()}
  if(m.type==='code'){const form=document.createElement('form'),label=document.createElement('label'),input=document.createElement('input'),submit=document.createElement('button');input.id='mechanism-input';input.name='code';input.autocomplete='off';input.inputMode=m.inputMode||'text';label.htmlFor=input.id;label.textContent='输入';submit.textContent='确认';submit.type='submit';form.append(label,input,submit);form.onsubmit=e=>{e.preventDefault();attempt(input.value)};body.append(form)}
  if(m.type==='sequence'){for(const token of m.tokens||[...new Set(m.answer)]){const b=document.createElement('button');b.textContent=String(token);b.onclick=()=>attempt(token);body.append(b)}}
  if(m.type==='switch'){const b=document.createElement('button');b.textContent='操作开关';b.onclick=()=>attempt(m.answer);body.append(b)}
  dialog.showModal();body.querySelector('input,button')?.focus();
 }
 $('#mechanism-close').onclick=()=>{dialog.close();onClose?.()};dialog.addEventListener('close',()=>onClose?.());return{open};
}
