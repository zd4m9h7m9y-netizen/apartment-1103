// Approved daily-event concepts expanded into 3–4 causally connected operations.
import {shuffleForRound} from './rounds.js';
export const EVENT_PLAN_VERSION=1;
export function createEventChain(event,round){
 const prefix=event.id+'.',v=event.outcome==='B'?1:event.outcome==='C'?2:0;
 const order=shuffleForRound(['月亮','窗户','星星'],round,prefix+'sequence');
 const matches={左格:'圆点',中格:'横线',右格:'方框'};
 const steps=[];
 const add=(name,kind,label,spec={})=>{steps.push({id:prefix+name,kind,label,target:prefix+(spec.target||name),...spec});return steps.at(-1)};
 const inspect=(name,label)=>add(name,'inspect',label);
 const collect=(name,label,items=[name])=>add(name,'collect',label,{grant:Object.fromEntries(items.map(x=>[prefix+x,1]))});
 const drag=(name,label,distance=24)=>add(name,'drag',label,{minimumDistance:distance});
 const sequence=(name,label)=>add(name,'sequence',label,{answer:order});
 const place=(name,label)=>add(name,'place',label,{answer:matches});
 const choose=(name,label,answer,options)=>add(name,'choose',label,{answer,options});
 const toggle=(name,label)=>add(name,'switch',label,{answer:true});
 const use=(item,target,label,consume=false)=>add(target,'use',label,{target:prefix+target,item:prefix+item,...consume?{consume:{[prefix+item]:1}}:{}});
 const combine=(a,b,out,label)=>add(out,'combine',label,{inputs:[prefix+a,prefix+b],consume:{[prefix+a]:1,[prefix+b]:1},grant:{[prefix+out]:1}});
 const npc=(actor,label)=>add('ask_'+actor,'npc',label,{actor});
 switch(event.id){
 case 'missing_remote':npc('bear','与 Bear 互动，让他留意遥控器');drag(v?'bed_cushion':'sofa_cushion','挪开 Bear 停留处的靠垫');collect('remote','取出露出的遥控器');use('remote','television','拿好遥控器，在电视上试用');break;
 case 'secret_channel':collect('remote','从电视旁拿起遥控器');use('remote','television','使用遥控器打开输入面板');sequence('channel_keys','根据收藏页的图标操作频道键');toggle('hidden_entry','打开刚出现的隐藏入口');break;
 case 'record_mystery':inspect('sleeve','检查封套上的播放标记');choose('side','切到标记对应的播放面',v?'B面':'A面',['A面','B面']);sequence('player_controls','按标记顺序操作唱片机');toggle('lamp','切换旁边的台灯，观察房间变化');break;
 case 'suspicious_plant':collect('cloth','从收纳处拿起清洁布');use('cloth','plant_tray','擦净底托露出的小标记');drag('plant','把花盆挪到旁边的安全位置');collect(v?'beside_pot':'under_tray','取出标记指向的小物件');break;
 case 'bookcase':inspect('spines','对照书脊上的标记');place('books','将三本书放回对应位置');sequence('latch','按露出的标记操作暗扣');collect(v?'side_slot':'drawer','打开收纳处并取出小物件');break;
 case 'apartment_chaos':inspect('state_marks','观察电视、唱片机和门铃的状态标记');toggle(v?'doorbell':'television','恢复第一个标记对应的开关');toggle('record_player','恢复唱片机开关');toggle(v?'television':'doorbell','恢复最后一个开关，结束连锁');break;
 case 'headphone_knot':inspect('cable_ends','找出线缆两端和可移动的结点');drag('outer_knot','先松开外侧结点');drag('inner_knot','再让内侧线段通过空位');add('plug','use','把理顺的插头放回播放器接口',{item:prefix+'headphones',grant:{[prefix+'headphones']:1},providedTool:true});break;
 case 'snack_standoff':collect('ball','拿起 Bear 的玩具球');use('ball','bear','用玩具吸引 Bear 的注意');drag('tray','挪开桌边的小托盘');collect('table_item','取回托盘旁的小物件');break;
 case 'desk_shuffle':inspect('tabs','对照三叠资料的边签');place('papers','把资料放回对应格位');drag('folder','移开挡住桌面角落的文件夹');collect('paper_corner','查看并收好露出的小纸片');break;
 case 'calendar_layers':collect('index_a','取下第一张透明索引片');collect('index_b','找到对应的第二张索引片');combine('index_a','index_b','overlay','在口袋组合两张索引片');use('overlay','calendar','把组合片对准日历的定位框');break;
 case 'vending_machine':inspect('slot','查看按钮和货槽的状态标记');collect('coin','拿起货槽旁的退回硬币');use('coin','machine','将硬币投入对应投币口',true);choose('retrieve','按照亮起的提示处理投递结果',['取出货槽物品','先按退回再取出','移开外层小物再取出'][v],['取出货槽物品','先按退回再取出','移开外层小物再取出']);break;
 case 'wrong_delivery':inspect('label','核对外包装与收件标签');drag('outer_flap','打开外层封口');drag('inner_divider','挪开内包装隔片');collect(['wrapped_item','outer_label','inner_receipt'][v],'检查刚露出的对应位置');break;
 case 'broken_elevator':inspect('floor_display','比较楼层显示与门外指示灯');toggle('control_mode','打开面板上的状态切换');sequence('floor_buttons','按可见标记恢复按钮顺序');toggle('restore','确认恢复正常显示和通行');break;
 case 'uninvited_guest':inspect('peephole','先从门边观察来客');npc('sammy','主动与门外的 Sammy 交流');choose('door_response','根据当前门边标记选择回应',v?'先看门边的小物件':'打开门',['打开门','先看门边的小物件']);collect(v?'doorstep_item':'visitor_item','检查来访后留下的普通小物');break;
 case 'mixed_doorbells':inspect('lights','观察门铃旁的灯与图形');sequence('buttons','按图形顺序尝试门铃');place('labels','把错位的门铃标签归位');toggle('confirm','确认对应门铃恢复');break;
 case 'noticeboard_shuffle':inspect('corners','找出公告边角的定位标记');drag('covering_notice','移开遮住其他纸张的公告');place('notices','把三张公告归位');collect('revealed_note','查看露出的那张纸条');break;
 case 'parcel_tower':inspect('box_marks','看清可移动箱子的标记');drag('top_box','先移开上层箱子');drag('bottom_box','再把下层箱子移到安全位置');collect(v?'side_item':'base_item','取出箱子旁或底部的小物');break;
 case 'lost_keyring':collect('keyring','从公共托盘取下钥匙串');inspect('tray','对照托盘上的图形');place('keys','按轮廓把钥匙对应归位');use('keyring','storage','尝试打开普通收纳托盘');break;
 case 'laundry_disaster':collect('supplies','根据标签拿齐洗涤用品',['detergent','water']);combine('detergent','water','mixture','按标签组合需要的洗涤用品');use('mixture','washer','将组合用品用于对应设备',true);if(v)place('clothing_roll','展开卷在一起的衣物并归位');else drag('foam_cover','处理遮住折叠台的泡沫');break;
 case 'bear_mischief':npc('bear','让 Bear 留意小物件');add('follow','follow','跟到 Bear 停下的位置',{actor:'bear',waypoint:prefix+'corner',maximumDistance:32});drag('obstruction','挪开他停留处的遮挡物');collect('hidden_item','取回 Bear 指出的小东西');break;
 case 'sock_constellation':inspect('patterns','对照袜子的边纹与图形');place('pairs','按边纹配对并归位');drag('basket','移开暂时挡住格位的篮子');collect('clip','取出露出的晾衣夹');break;
 case 'laundry_labels':collect('garment','拿起带洗涤标签的衣物');choose('machine','根据标签选择对应设备',v?'烘干机':'洗衣机',['洗衣机','烘干机']);toggle('setting','按标签调整设备设置');use('garment','selected_machine','将衣物放入已经确认的设备');break;
 case 'folding_table':drag('first_fold','沿第一个折叠方向展开衣物');drag('second_fold','沿第二个方向整理边角');place('folded_stack','把衣物放进标记出的空位');collect('under_stack','查看原先被衣物盖住的位置');break;
 case 'dryer_rattle':inspect('stop_light','查看机器的停止提示');toggle('stop','确认设备停下');choose('visible_part','按标记检查可直接打开的位置',v?'门边收纳盒':'滤网盒',['门边收纳盒','滤网盒']);collect('loose_item','取出发出轻响的小物');break;
 case 'locker_echo':inspect('symbols','查看柜门上的图标');sequence('locks','按图标顺序操作按钮');toggle('latch','打开已经松开的柜扣');collect('cabinet_item','取出柜格中的普通物件');break;
 case 'tool_tray':inspect('outlines','观察工具托盘的轮廓');collect('tools','拿起散放的工具');place('tool_slots','把工具放回对应轮廓');drag('tray_cover','移开已经露出的托盘小盖');break;
 case 'bear_ball':npc('bear','让 Bear 指出玩具的位置');add('follow','follow','跟到 Bear 留意的家具旁',{actor:'bear',waypoint:prefix+'toy_corner',maximumDistance:32});drag('toy_basket','挪开挡住玩具的收纳筐');collect('ball','把球取回并放到玩具处');break;
 case 'bookmarks':npc('ann','主动问 Ann 书签的标记');inspect('page_marks','对照书页上的定位符号');place('bookmark_slots','将书签放回对应页边');collect('reading_note','查看整理后露出的阅读备注');break;
 case 'shopping_list':collect('list','拿起公共桌上的购物清单');inspect('item_labels','查看几件普通物品的标签');place('list_slots','把标签与清单空位对应起来');choose('extra','把不属于这份清单的物件放回原处',v?'多出的标签':'空包装',['多出的标签','空包装']);break;
 case 'light_circuit':inspect('diagram','对照台灯旁的图形');toggle(v?'lamp_right':'lamp_left','调整第一盏台灯');toggle(v?'lamp_left':'lamp_right','调整另一盏台灯');toggle('pattern','确认两盏灯与图形对应');break;
 default:throw Error('Missing event chain: '+event.id);
 }
 // The first round keeps three meaningful steps for its introductory events.
 if(event.mode==='intro'){
  if(event.id==='missing_remote')steps.pop();
  if(event.id==='vending_machine')steps.shift();
  if(['folding_table','bookmarks'].includes(event.id))steps.pop();
 }
 return {version:EVENT_PLAN_VERSION,eventId:event.id,outcome:event.outcome,steps,resultState:event.id+'.'+event.outcome+'.resolved'};
}
function equal(a,b){if(Array.isArray(a)&&Array.isArray(b))return a.length===b.length&&a.every((x,i)=>equal(x,b[i]));if(a&&b&&typeof a==='object'&&typeof b==='object'){const keys=Object.keys(a);return keys.length===Object.keys(b).length&&keys.every(k=>equal(a[k],b[k]))}return a===b}
export function validateEventAction(step,input){
 if(!input||input.kind!==step.kind||input.target!==step.target)return{ok:false,reason:'wrong-action'};
 if(['inspect','collect'].includes(step.kind))return{ok:true};
 if(step.kind==='npc')return input.npcId===step.actor&&input.conversationCompleted===true?{ok:true}:{ok:false,reason:'talk-to-character'};
 if(step.kind==='follow')return input.npcId===step.actor&&input.waypoint===step.waypoint&&input.arrived===true&&Number.isFinite(input.distance)&&input.distance<=step.maximumDistance?{ok:true}:{ok:false,reason:'follow-character'};
 if(step.kind==='drag'){if(!input.valid||!Array.isArray(input.from)||!Array.isArray(input.to)||input.from.length!==2||input.to.length!==2||![...input.from,...input.to].every(Number.isFinite))return{ok:false,reason:'invalid-placement'};return Math.hypot(input.to[0]-input.from[0],input.to[1]-input.from[1])>=step.minimumDistance?{ok:true}:{ok:false,reason:'move-further'}}
 if(step.kind==='use')return input.item===step.item?{ok:true}:{ok:false,reason:'wrong-item'};
 if(step.kind==='combine')return Array.isArray(input.items)&&equal([...input.items].sort(),[...step.inputs].sort())?{ok:true}:{ok:false,reason:'wrong-combination'};
 return equal(input.value,step.answer)?{ok:true}:{ok:false,reason:'incorrect'};
}
