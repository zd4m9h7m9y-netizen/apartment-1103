// Generic mechanics only. Narrative definitions are supplied separately after approval.
const copy=x=>structuredClone(x);
const ok=(extra={})=>({ok:true,...extra});const fail=reason=>({ok:false,reason});
export class Adventure {
 constructor(definitions={},saved={}){
  this.defs={items:{},pickups:{},recipes:[],uses:[],mechanisms:{},areas:{},...definitions};
  this.state={version:1,inventory:{},claimed:[],completed:[],flags:{},clues:[],unlocked:[],mechanisms:{},inspected:[],ambient:{},...copy(saved)};this.listeners=[];
  for(const key of ['inventory','flags','mechanisms','ambient'])if(!this.state[key]||typeof this.state[key]!=='object'||Array.isArray(this.state[key]))this.state[key]={};
  for(const key of ['claimed','completed','clues','unlocked','inspected'])if(!Array.isArray(this.state[key]))this.state[key]=[];
  for(const [id,n]of Object.entries(this.state.inventory))if(!this.defs.items[id]||!Number.isInteger(n)||n<=0)delete this.state.inventory[id];
  this.validate();
 }
 validate(){
  const checkEffect=e=>{for(const id of Object.keys(e?.grant||{}))if(!this.defs.items[id])throw Error(`Unknown item: ${id}`);for(const n of Object.values(e?.grant||{}))if(!Number.isInteger(n)||n<=0)throw Error('Invalid item count')};
  for(const p of Object.values(this.defs.pickups)){if(!this.defs.items[p.item])throw Error(`Unknown pickup item: ${p.item}`);checkEffect(p.effects)}
  for(const r of this.defs.recipes){if(!r.id||r.inputs?.length!==2||r.inputs.some(id=>!this.defs.items[id]))throw Error('Recipes need two registered items');checkEffect(r.effects)}
  for(const u of this.defs.uses){if(!u.id||!this.defs.items[u.item]||!u.target)throw Error('Invalid use');checkEffect(u.effects)}
  for(const m of Object.values(this.defs.mechanisms)){if(!['code','sequence','switch','drag'].includes(m.type))throw Error('Unknown mechanism');if(m.type==='sequence'&&!m.answer?.length)throw Error('Empty sequence');if(m.type==='drag'&&(!m.origin||!Number.isFinite(m.distance)||m.distance<=0))throw Error('Invalid drag');checkEffect(m.effects)}
 }
 subscribe(fn){this.listeners.push(fn);return()=>this.listeners=this.listeners.filter(x=>x!==fn)}
 changed(){for(const fn of this.listeners)fn(this.snapshot())}
 snapshot(){return copy(this.state)}
 count(id){return this.state.inventory[id]||0}
 meets(rule){
  if(!rule)return true;if(rule.all)return rule.all.every(r=>this.meets(r));if(rule.any)return rule.any.some(r=>this.meets(r));if(rule.not)return !this.meets(rule.not);
  if(rule.flag)return this.state.flags[rule.flag]===(rule.value??true);if(rule.item)return this.count(rule.item)>=(rule.count||1);if(rule.completed)return this.state.completed.includes(rule.completed);if(rule.clue)return this.state.clues.some(c=>c.id===rule.clue);return false;
 }
 // Effects commit atomically after both requirements and consumed quantities pass.
 transact(id,requires,effects={},consume={}){
  if(this.state.completed.includes(id))return ok({already:true});if(!this.meets(requires))return fail('conditions');
  for(const [item,n]of Object.entries(consume))if(!Number.isInteger(n)||n<=0||this.count(item)<n)return fail('missing-item');
  for(const [item,n]of Object.entries(effects.grant||{}))if(!this.defs.items[item]||!Number.isInteger(n)||n<=0)return fail('invalid-effect');
  const next=copy(this.state);
  for(const [item,n]of Object.entries(consume)){next.inventory[item]-=n;if(!next.inventory[item])delete next.inventory[item]}
  for(const [item,n]of Object.entries(effects.grant||{}))next.inventory[item]=(next.inventory[item]||0)+n;
  Object.assign(next.flags,effects.flags||{});
  for(const c of effects.clues||[])if(!next.clues.some(x=>x.id===c.id))next.clues.push(copy(c));
  for(const area of effects.unlock||[])if(!next.unlocked.includes(area))next.unlocked.push(area);
  next.completed.push(id);this.state=next;this.changed();return ok({changed:true});
 }
 pickup(objectId){const p=this.defs.pickups[objectId];if(!p)return fail('unknown-pickup');if(this.state.claimed.includes(objectId))return ok({already:true});const result=this.transact('pickup:'+objectId,p.requires,{...p.effects,grant:{...p.effects?.grant,[p.item]:(p.count||1)+(p.effects?.grant?.[p.item]||0)}});if(result.ok){this.state.claimed.push(objectId);this.changed()}return result}
 visiblePickup(id){const p=this.defs.pickups[id];return !!p&&!this.state.claimed.includes(id)&&this.meets(p.requires)}
 combine(ids){
  if(ids.length!==2)return fail('choose-two');const key=[...ids].sort().join('|'),r=this.defs.recipes.find(r=>[...r.inputs].sort().join('|')===key);if(!r)return fail('no-recipe');
  const quantities={};for(const id of ids)quantities[id]=(quantities[id]||0)+1;
  // Verify the current inputs even when a previous attempt produced the same recipe.
  for(const [id,n]of Object.entries(quantities))if(this.count(id)<n)return fail('missing-item');
  if(this.state.completed.includes('recipe:'+r.id))return ok({already:true});return this.transact('recipe:'+r.id,r.requires,r.effects,quantities);
 }
 use(item,target){const u=this.defs.uses.find(u=>u.item===item&&u.target===target);if(!u)return fail('wrong-target');if(this.count(item)<(u.consume||1))return fail('missing-item');return this.transact('use:'+u.id,u.requires,u.effects,u.consume?{[item]:u.consume}:{})}
 operate(id,input){
  const m=this.defs.mechanisms[id];if(!m)return fail('unknown-mechanism');if(this.state.completed.includes('mechanism:'+id))return ok({already:true});if(!this.meets(m.requires))return fail('conditions');
  let solved=false;
  if(m.type==='code')solved=String(input)===String(m.answer);
  if(m.type==='switch')solved=input===m.answer;
  if(m.type==='drag'){if(!input?.valid||!Number.isFinite(input.x)||!Number.isFinite(input.y))return fail('invalid-placement');solved=Math.hypot(input.x-m.origin[0],input.y-m.origin[1])>=m.distance}
  if(m.type==='sequence'){
   let progress=this.state.mechanisms[id]?.progress||0;
   if(input===m.answer[progress])progress++;else progress=input===m.answer[0]?1:0;
   this.state.mechanisms[id]={progress};this.changed();solved=progress===m.answer.length;if(!solved)return fail(progress?'in-progress':'wrong-order');
  }
  if(!solved)return fail(m.type==='drag'?'move-further':'incorrect');return this.transact('mechanism:'+id,m.requires,m.effects);
 }
 areaStatus(id){const a=this.defs.areas[id];if(!a)return{open:true};if(a.status==='awaiting-approval')return{open:false,pending:true};if(this.state.unlocked.includes(id))return{open:true};return{open:false,pending:false,ready:this.meets(a.requires)}}
 unlockArea(id){const a=this.defs.areas[id];if(!a)return fail('unknown-area');if(a.status==='awaiting-approval')return fail('awaiting-approval');return this.transact('area:'+id,a.requires,{unlock:[id]})}
 inspect(id){if(this.state.inspected.includes(id))return false;this.state.inspected.push(id);this.changed();return true}
 clue(id,text,source='environment'){if(this.state.clues.some(x=>x.id===id))return false;this.state.clues.push({id,text,source});this.changed();return true}
 ambient(id,choices,random=Math.random){if(!(id in this.state.ambient)){this.state.ambient[id]=choices[Math.min(choices.length-1,Math.floor(random()*choices.length))];this.changed()}return this.state.ambient[id]}
}
