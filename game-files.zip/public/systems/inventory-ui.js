export function createInventoryUI({system,save,notify,onOpen,onClose,onUse}){
 const $=s=>document.querySelector(s);let chosen=[],held=null;const dialog=$('#inventory');
 const messages={'no-recipe':'这两件物品暂时不能组合。','missing-item':'口袋里没有足够的物品。','conditions':'还没有满足使用条件。','wrong-target':'这件物品不能用在这里。','choose-two':'请选择两件物品。'};
 function render(){chosen=chosen.filter(id=>system.count(id));if(held&&!system.count(held))held=null;const grid=$('#inventory-grid');grid.replaceChildren();
  for(const [id,n]of Object.entries(system.state.inventory)){
   const def=system.defs.items[id],b=document.createElement('button');b.type='button';b.className='inventory-item';b.dataset.item=id;b.setAttribute('aria-pressed',String(chosen.includes(id)));
   if(def.icon){const im=new Image;im.src=def.icon;im.alt='';b.append(im)}const label=document.createElement('span');label.textContent=def.name+(n>1?` × ${n}`:'');b.append(label);b.onclick=()=>{if(chosen.includes(id))chosen=chosen.filter(x=>x!==id);else{if(chosen.length===2)chosen.shift();chosen.push(id)}render()};grid.append(b)
  }
  if(!Object.keys(system.state.inventory).length){const text=document.createElement('p');text.textContent='口袋还是空的。找到可收集的物品后，它们会保存在这里。';grid.append(text)}
  $('#inventory-description').textContent=chosen.length?chosen.map(id=>system.defs.items[id].description||system.defs.items[id].name).join('\n\n'):'选一件物品查看或拿在手上；选两件物品尝试组合。';
  $('#inventory-use').disabled=chosen.length!==1;$('#inventory-combine').disabled=chosen.length!==2;$('#inventory-count').textContent=Object.values(system.state.inventory).reduce((a,b)=>a+b,0);$('#held-label').textContent=held?`拿着：${system.defs.items[held].name}`:'口袋';$('#put-away').hidden=!held;
  const list=$('#clue-list');list.replaceChildren();for(const c of system.state.clues){const p=document.createElement('p');p.textContent=c.text;list.append(p)}if(!system.state.clues.length)list.textContent='发现的线索会记录在这里。';
 }
 function close(){dialog.close();onClose?.()}
 function open(){chosen=[];$('#inventory-feedback').textContent='';render();onOpen?.();if(!dialog.open)dialog.showModal()}
 $('#inventory-button').onclick=open;$('#inventory-close').onclick=close;dialog.addEventListener('close',()=>onClose?.());
 $('#inventory-use').onclick=()=>{held=chosen[0];render();close();notify(`拿好${system.defs.items[held].name}，点击目标使用。`)};
 $('#inventory-combine').onclick=()=>{const r=system.combine(chosen);chosen=[];render();$('#inventory-feedback').textContent=r.ok?(r.already?'这次组合已经完成。':'组合成功，新物品已收入口袋。'):(messages[r.reason]||'暂时无法组合。');save()};
 $('#put-away').onclick=()=>{held=null;render()};
 system.subscribe(render);render();return{open,render,clearHeld(){held=null;render()},get held(){return held},use(target){if(!held)return false;const item=held,r=system.use(item,target);if(r.ok)held=null;notify(r.ok?(r.already?'这项操作已经完成。':'物品使用成功。'):(messages[r.reason]||'暂时无法使用。'));render();save();onUse?.({item,target,result:r});return true}};
}
