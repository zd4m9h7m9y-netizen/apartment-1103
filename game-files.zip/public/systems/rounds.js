// Generic round generation. This module contains no production story or puzzle data.
function hash(text){let h=2166136261;for(const c of String(text)){h^=c.charCodeAt(0);h=Math.imul(h,16777619)}return h>>>0}
function randomFor(seed,label){let n=hash(`${seed}:${label}`);return()=>{n+=0x6D2B79F5;let t=n;t=Math.imul(t^(t>>>15),t|1);t^=t+Math.imul(t^(t>>>7),t|61);return((t^(t>>>14))>>>0)/4294967296}}
export function newSeed(){const a=new Uint32Array(2);crypto.getRandomValues(a);return [...a].map(x=>x.toString(16).padStart(8,'0')).join('')}
export function generateRound({seed=newSeed(),number=1,slots=[],previous=null,ruleset='technical-v1'}={}){
 if(!Number.isInteger(number)||number<1)throw Error('Invalid round number');const seen=new Set,choices={};
 for(const slot of slots){
  if(!slot.id||seen.has(slot.id)||!Array.isArray(slot.options)||!slot.options.length||new Set(slot.options).size!==slot.options.length||slot.options.some(x=>typeof x!=='string'))throw Error('Invalid round slot');seen.add(slot.id);
  const pool=slot.options.length>1&&previous?.choices?.[slot.id]?slot.options.filter(x=>x!==previous.choices[slot.id]):slot.options;
  choices[slot.id]=pool[Math.floor(randomFor(seed,slot.id)()*pool.length)];
 }
 return {version:1,ruleset,number,seed,choices};
}
export function restoreRound(saved){if(saved?.version!==1||typeof saved.seed!=='string'||!Number.isInteger(saved.number)||saved.number<1||!saved.choices||typeof saved.choices!=='object')throw Error('Invalid saved round');return structuredClone(saved)}
export function shuffleForRound(values,round,label){const a=[...values],random=randomFor(round.seed,label);for(let i=a.length-1;i>0;i--){const j=Math.floor(random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a}
// Graphs are validated before content registration. Random variants must preserve their dependencies.
export function validateDependencyGraph(nodes,initial=[]){
 const ids=new Set;for(const node of nodes){if(!node.id||ids.has(node.id))return {ok:false,reason:'duplicate-node'};ids.add(node.id)}
 const available=new Set(initial),done=new Set;let changed=true;
 while(changed){changed=false;for(const node of nodes){if(done.has(node.id)||!(node.requires||[]).every(x=>available.has(x)))continue;done.add(node.id);for(const reward of node.produces||[])available.add(reward);changed=true}}
 const blocked=nodes.filter(n=>!done.has(n.id)).map(n=>n.id);return{ok:!blocked.length,blocked};
}
