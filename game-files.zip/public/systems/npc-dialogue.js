import {shuffleForRound} from './rounds.js';
import {INTRO,DAILY,ROOF_READY,BIRTHDAY,ITEM_REACTIONS,DISCOVERY_TOPICS,HINT_LINES} from './npc-lines.js';
export {INTRO,DAILY,ROOF_READY,BIRTHDAY,ITEM_REACTIONS,DISCOVERY_TOPICS,HINT_LINES};
export class NpcConversationState {
 constructor(system,round){this.system=system;this.round=round;system.state.dialogueHistory||={ann:[],sammy:[]};for(const npc of ['ann','sammy'])system.state.dialogueHistory[npc]||=[]}
 seen(npc,id){return this.system.state.inspected.includes(`npc:${npc}:${id}`)}
 record(npc,id,title,text){
  if(this.seen(npc,id))return false;
  this.system.state.dialogueHistory[npc].push({id,title,text});this.system.inspect(`npc:${npc}:${id}`);return true;
 }
 history(npc){return this.system.state.dialogueHistory[npc].map(x=>({...x}))}
 daily(npc){return shuffleForRound(DAILY[npc],this.round,'npc.daily.'+npc)[0]}
 items(npc){return Object.keys(this.system.state.inventory).filter(id=>this.system.count(id)>0&&ITEM_REACTIONS[id]?.[npc])}
 topics(npc,discoveries){return DISCOVERY_TOPICS.filter(t=>t.npc===npc&&t.requires.some(id=>!!discoveries[id]))}
 itemText(npc,item){return this.system.count(item)>0?ITEM_REACTIONS[item]?.[npc]:null}
 step(chain){
  const s=this.system;
  if(s.state.flags.rooftopReady)return'roof-ready';
  if(chain==='A'){if(!s.state.completed.includes('mechanism:music.sequence'))return'A.music';if(!s.state.flags.laundryReleased)return'A.ticket';if(!s.state.claimed.includes('a.pouch'))return'A.basket';return'A.join'}
  if(chain==='B'){if(!s.state.claimed.includes('apartment_4b.drawer.12'))return'B.left';if(!s.state.claimed.includes('b.postcard'))return'B.right';return'B.code'}
  if(!s.count('icon_guide'))return'C.guide';if(!s.count('message_card'))return'C.book';if(!s.count('sequence_card'))return'C.box';return'C.panel';
 }
}
export function createNpcDialogue({system,round,campaign,archive,talk,onInteraction=()=>{}}){
 const memory=new NpcConversationState(system,round),name=npc=>npc==='ann'?'ANN':'SAMMY';
 const back=npc=>({label:'继续聊天',action:()=>menu(npc)}),exit={label:'待会儿见',action:()=>{}};
 function say(npc,id,title,text,actions){memory.record(npc,id,title,text);talk(name(npc),title,text,actions||[back(npc),exit])}
 function replayOrSay(npc,id,title,text,actions){if(memory.seen(npc,id)){talk('谈话记录','这段已经聊过了','可以主动回顾，或换个话题。',[{label:'回顾这段',action:()=>talk(name(npc),title,text,actions||[back(npc),exit])},back(npc),exit]);return}say(npc,id,title,text,actions)}
 function menu(npc){talk(name(npc),'想聊点什么？','可以随便聊聊、展示物品，或主动询问提示。',[{label:'随便聊聊',action:()=>daily(npc)},{label:'给你看个东西',action:()=>itemMenu(npc)},{label:'聊聊刚发现的东西',action:()=>topicMenu(npc)},{label:'我卡住了',action:()=>hint(npc)},...(memory.history(npc).length?[{label:'谈话记录',action:()=>history(npc)}]:[]),exit])}
 function daily(npc){const line=memory.daily(npc);replayOrSay(npc,'daily','随便聊聊',line.text,[{label:'再坐一会儿',action:()=>menu(npc)},{label:'我继续逛逛',action:()=>{}}])}
 function itemMenu(npc){const items=memory.items(npc);talk('口袋','给'+(npc==='ann'?' Ann':' Sammy')+'看个东西',items.length?'只展示物品，不消耗，也不会替你完成谜题。':'口袋里还没有可展示的话题物品。',[...items.map(item=>({label:system.defs.items[item].name,action:()=>showItem(npc,item)})),back(npc),exit])}
 function showItem(npc,item){const text=memory.itemText(npc,item);if(!text){talk('口袋','暂时没有对应话题','这件物品没有可展示的回应，物品仍在口袋里。',[back(npc),exit]);return false}replayOrSay(npc,'item:'+item,system.defs.items[item].name,text);return true}
 function topicMenu(npc){const topics=memory.topics(npc,archive.discoveries);talk('发现记录','聊聊刚发现的东西',topics.length?'选择已经发现的话题。':'还没有发现对应的小物件。可以继续逛逛。',[...topics.map(t=>({label:t.label,action:()=>replayOrSay(npc,'topic:'+t.id,t.label,t.text)})),back(npc),exit])}
 function hint(npc){const step=memory.step(campaign.chain),line=HINT_LINES[step]?.[npc];say(npc,'hint:'+step,'一点提示',line||campaign.hint(system,1),[{label:'再具体一点',action:()=>talk('探索提示','下一步',campaign.hint(system,1),[{label:'显示这一步怎么做',action:()=>talk('探索提示','这一步的操作',campaign.hint(system,2),[back(npc),exit])},back(npc),exit])},back(npc),exit])}
 function history(npc){const records=memory.history(npc);talk('谈话记录',npc==='ann'?'Ann':'Sammy','选择一段主动回顾。',[...records.map(r=>({label:r.title,action:()=>talk(name(npc),r.title,r.text,[back(npc),exit])})),back(npc),exit])}
 function open(npc,{birthday=false,roofReady=false,item=null}={}){
  if(!['ann','sammy'].includes(npc))return;system.inspect(npc);onInteraction(npc);
  if(birthday){replayOrSay(npc,'greeting:birthday',npc==='ann'?'生日快乐，Olivia。':'都准备好了。',BIRTHDAY[npc]);return}
  if(item){showItem(npc,item);return}
  if(roofReady&&!memory.seen(npc,'greeting:roof-ready')){say(npc,'greeting:roof-ready','天台的灯亮了。',ROOF_READY[npc]);return}
  if(!memory.seen(npc,'greeting:first')){
   const intro=INTRO[npc];say(npc,'greeting:first',npc==='ann'?'来得正好。':'进来吧。',intro.text,intro.choices.map(([id,label,response])=>({label,action:()=>{if(!response){hint(npc);return}system.state.flags[`npc.${npc}.intro.choice`]=id;say(npc,'intro:'+id,label,response)}})));return;
  }
  menu(npc);
 }
 return{open,memory,menu,showItem,hint};
}
