export const PERSONAL_OBJECTS=[
 {scene:'apartment_4b',id:'personal.punisher',asset:'punisher',x:273,y:136,depth:193,label:'Phoebe Bridgers · Punisher',title:'Punisher',text:'Phoebe Bridgers · Punisher\n唱片架里专门留出的一格。',kind:'音乐收藏'},
 {scene:'apartment_4b',id:'personal.evermore',asset:'evermore',x:28,y:79,depth:129,label:'Taylor Swift · evermore',title:'evermore',text:'Taylor Swift · evermore\n最喜欢的 Taylor Swift 专辑，放在伸手就能拿到的地方。',kind:'音乐收藏'},
 {scene:'apartment_4b',id:'personal.headphones',asset:'headphones',x:240,y:176,label:'耳机',title:'耳机',text:'耳罩、线缆，还有一点安静。',kind:'生活小物'},
 {scene:'apartment_4b',id:'personal.economics',asset:'economics',x:370,y:275,depth:321,label:'Economics · A-Level',title:'Economics',text:'A-Level · Economics\n书页间夹着复习用的标记。',kind:'学习桌'},
 {scene:'apartment_4b',id:'personal.pomelo',asset:'pomelo',x:533,y:247,depth:297,label:'一小碗柚子',title:'柚子',text:'剥好的柚子放在小碗里，旁边还留着一点果皮。',kind:'生活小物'},
 {scene:'apartment_4b',id:'personal.ribs',asset:'music_player',x:449,y:119,depth:161,label:'Lorde · Ribs',title:'Ribs',text:'Lorde · Ribs\n播放器的收藏列表停在这一首。',kind:'音乐收藏'},
 {scene:'apartment_4b',id:'personal.rootshaw',asset:'screen_box',x:28,y:222,label:'薄薄的影视收藏盒',title:'收藏盒的内页',text:'Person of Interest\n\nRoot\nSameen Shaw\n\n两张小小的收藏标签，藏在封面后面。',kind:'隐藏收藏',hiddenReveal:true}
];
export const TV_COLLECTION='Brooklyn Nine-Nine\nFriends · Phoebe\nPerson of Interest · Root / Sameen Shaw\nHacks\nSaturday Night Live\nThe Pitt · McKay\n\n喜剧人收藏：Ania Magliano';
export const RECORD_COLLECTION='Phoebe Bridgers · Punisher\nTaylor Swift · evermore\nLorde · Ribs\nOlivia Rodrigo\nbeabadoobee\nSabrina Carpenter';
export function patchPersonal(maps){for(const p of PERSONAL_OBJECTS)maps[p.scene].objects.push({width:32,height:32,eventId:'personal.inspect',layer:'world',collider:null,draggable:false,...p})}
