import {createEventChain,validateEventAction} from './event-chains.js';
// Event-driven redesign. Production dialogue/art for new events still follows author review.
import {generateRound,shuffleForRound} from './rounds.js';
export const AREA_ORDER=['apartment_4b','hallway','laundry_room','apartment_4c','rooftop'];
const event=(id,title,room,anchor,outcomes=['A','B'])=>({id,title,room,anchors:[anchor],outcomes});
export const EVENT_LIBRARY=Object.freeze([
 event('missing_remote','Missing Remote','apartment_4b','sofa'),
 event('secret_channel','Secret Channel','apartment_4b','television'),
 event('record_mystery','Record Mystery','apartment_4b','record_player'),
 event('suspicious_plant','Suspicious Plant','apartment_4b','plant'),
 event('bookcase','The Bookcase','apartment_4b','bookcase'),
 event('apartment_chaos','Apartment Chaos','apartment_4b','room_switches'),
 event('headphone_knot','Headphone Knot','apartment_4b','headphones'),
 event('snack_standoff','Snack Standoff','apartment_4b','snack_table'),
 event('desk_shuffle','Desk Shuffle','apartment_4b','study_desk'),
 event('calendar_layers','Calendar Layers','apartment_4b','calendar'),
 event('vending_machine','Vending Machine','hallway','vending',['A','B','C']),
 event('wrong_delivery','Wrong Delivery','hallway','parcel',['A','B','C']),
 event('broken_elevator','Broken Elevator','hallway','elevator'),
 event('uninvited_guest','The Uninvited Guest','hallway','door'),
 event('mixed_doorbells','Mixed Doorbells','hallway','doorbells'),
 event('noticeboard_shuffle','Noticeboard Shuffle','hallway','noticeboard'),
 event('parcel_tower','Parcel Tower','hallway','parcel_tower'),
 event('lost_keyring','Lost Keyring','hallway','key_tray'),
 event('laundry_disaster','Laundry Disaster','laundry_room','washer'),
 event('bear_mischief','Bear on the Loose','laundry_room','bear'),
 event('sock_constellation','Sock Constellation','laundry_room','socks'),
 event('laundry_labels','Laundry Labels','laundry_room','labels'),
 event('folding_table','Folding Table','laundry_room','folding_table'),
 event('dryer_rattle','Dryer Rattle','laundry_room','dryer'),
 event('locker_echo','Locker Echo','laundry_room','locker'),
 event('tool_tray','Tool Tray','apartment_4c','tools'),
 event('bear_ball','Bear’s Ball','apartment_4c','bear_ball'),
 event('bookmarks','Bookmarks','apartment_4c','reading_desk'),
 event('shopping_list','The Shopping List','apartment_4c','public_table'),
 event('light_circuit','Light Circuit','apartment_4c','lamps')
]);
export const NPC_SCHEDULE=Object.freeze({apartment_4b:['bear'],hallway:['sammy'],laundry_room:['bear'],apartment_4c:['ann'],rooftop:['ann','sammy','bear']});
export function createEpisode({seed,number=1,previous=null}={}){
 const round=generateRound({seed,number,previous,ruleset:'apartment1103-area-episodes-v2',slots:[{id:'weather',options:['clear','rain','snow']},{id:'lighting',options:['warm','dim']},{id:'activity',options:['reading','sorting','resting']},{id:'variant',options:['one','two','three']}]});
 const intro={apartment_4b:'missing_remote',hallway:'vending_machine',laundry_room:'folding_table',apartment_4c:'bookmarks'};
 round.events=AREA_ORDER.slice(0,-1).map(room=>{
  const pool=EVENT_LIBRARY.filter(e=>e.room===room),last=previous?.events.find(e=>e.room===room)?.id,available=pool.filter(e=>e.id!==last);
  const e=number===1?pool.find(e=>e.id===intro[room]):shuffleForRound(available.length?available:pool,round,'event:'+room)[0];
  return {id:e.id,room,outcome:shuffleForRound(e.outcomes,round,'outcome:'+e.id)[0],mode:number===1?'intro':'full'};
 });round.petActor='bear';round.eventPlanVersion=1;for(const e of round.events)e.plan=createEventChain(e,round);return round;
}
export class EpisodeProgress {
 constructor({round,profile={},saved={},clueThreshold,requireSocial=true,minimumCompletedEvents=1}){
  if(!Number.isInteger(clueThreshold)||clueThreshold<1)throw Error('Explicit approved clue threshold required');
  this.round=structuredClone(round);this.profile={birthdayUnlocked:false,discoveries:{},...structuredClone(profile)};
  this.state={events:{},birthdayClues:{},items:{},openAreas:['apartment_4b'],visited:[],npcInteractions:[],rooftopOpen:false,...structuredClone(saved)};
  this.state.items||={};for(const e of this.round.events)e.plan||=createEventChain(e,this.round);
  this.clueThreshold=clueThreshold;this.requireSocial=requireSocial;this.minimumCompletedEvents=minimumCompletedEvents;
 }
 enter(room){if(!this.state.openAreas.includes(room))return{ok:false,reason:'area-locked'};if(!this.state.visited.includes(room))this.state.visited.push(room);this.state.currentRoom=room;return{ok:true}}
 start(id){const e=this.round.events.find(e=>e.id===id);if(!e)return{ok:false,reason:'not-in-this-episode'};if(!this.state.visited.includes(e.room)||this.state.currentRoom!==e.room)return{ok:false,reason:'room-not-visited'};this.state.events[id]||={status:'active',progress:{}};return{ok:true,already:this.state.events[id].status==='complete'}}
 nextStep(id){const e=this.round.events.find(e=>e.id===id);if(!e||this.state.events[id]?.status==='complete')return null;return structuredClone(e.plan.steps[(this.state.events[id]?.progress?.steps||[]).length]||null)}
 perform(id,input){
  const started=this.start(id);if(!started.ok||started.already)return started;
  const event=this.round.events.find(e=>e.id===id),step=this.nextStep(id);if(!step)return{ok:false,reason:'no-active-step'};
  const valid=validateEventAction(step,input);if(!valid.ok)return valid;
  const needed={...step.consume};if(step.kind==='use'&&!step.providedTool)needed[step.item]=Math.max(needed[step.item]||0,1);
  for(const [item,n]of Object.entries(needed))if((this.state.items[item]||0)<n)return{ok:false,reason:'missing-item'};
  if(step.kind==='npc'&&!this.availableNpcs(this.state.currentRoom).includes(input.npcId))return{ok:false,reason:'npc-not-present'};
  for(const [item,n]of Object.entries(step.consume||{})){this.state.items[item]-=n;if(!this.state.items[item])delete this.state.items[item]}
  for(const [item,n]of Object.entries(step.grant||{}))this.state.items[item]=(this.state.items[item]||0)+n;
  const current=this.state.events[id];current.progress.steps||=[];current.progress.steps.push({id:step.id,kind:step.kind,target:step.target});
  if(step.kind==='npc')this.interactNpc(input.npcId,{gaveClue:input.gaveBirthdayClue===true});
  const complete=current.progress.steps.length===event.plan.steps.length;
  if(complete){const result=this.complete(id,{outcome:event.outcome,sceneState:event.plan.resultState});return{...result,eventComplete:!!result.ok,stepId:step.id}}
  return{ok:true,eventComplete:false,stepId:step.id,nextStep:this.nextStep(id)};
 }
 complete(id,result={}){const e=this.start(id);if(!e.ok||e.already)return e;const event=this.round.events.find(e=>e.id===id),finished=this.state.events[id].progress.steps||[];
  if(finished.length!==event.plan.steps.length)return{ok:false,reason:'steps-remaining',remaining:event.plan.steps.length-finished.length};
  this.state.events[id]={...this.state.events[id],status:'complete',result:structuredClone(result)};const room=event.room,index=AREA_ORDER.indexOf(room),next=AREA_ORDER[index+1];if(next!=='rooftop'&&!this.state.openAreas.includes(next))this.state.openAreas.push(next);this.checkBirthday();return{ok:true}}
 availableNpcs(room){const result=new Set(NPC_SCHEDULE[room]||[]);for(const e of this.round.events)if(e.room===room)for(const step of e.plan.steps)if(['npc','follow'].includes(step.kind))result.add(step.actor);return [...result]}
 interactNpc(id,{gaveClue=false}={}){if(!['ann','sammy','bear'].includes(id)||!this.availableNpcs(this.state.currentRoom).includes(id))return{ok:false,reason:'npc-not-present'};if(!this.state.npcInteractions.includes(id))this.state.npcInteractions.push(id);if(gaveClue)this.clue('npc:'+id,id==='bear'?'dog':'npc');this.checkBirthday();return{ok:true}}
 clue(id,source){if(!['environment','npc','dog','event'].includes(source))return{ok:false};if(this.state.birthdayClues[id])return{ok:true,already:true};this.state.birthdayClues[id]={source};this.checkBirthday();return{ok:true}}
 checkBirthday(){const clues=Object.values(this.state.birthdayClues),allRooms=AREA_ORDER.slice(0,-1).every(id=>this.state.visited.includes(id)),allLocalEvents=this.round.events.every(e=>this.state.events[e.id]?.status==='complete');
  if(allRooms&&allLocalEvents&&this.state.npcInteractions.length>=2&&Object.values(this.state.events).filter(e=>e.status==='complete').length>=this.minimumCompletedEvents&&clues.length>=this.clueThreshold&&(!this.requireSocial||clues.some(c=>['npc','dog'].includes(c.source)))){
   this.state.rooftopOpen=true;this.profile.birthdayUnlocked=true;if(!this.state.openAreas.includes('rooftop'))this.state.openAreas.push('rooftop');
  }return this.state.rooftopOpen;
 }
 canEnterRooftop(){return !!this.state.rooftopOpen}
 allRoomsVisited(){return AREA_ORDER.every(id=>this.state.visited.includes(id))}
 snapshot(){return{round:structuredClone(this.round),profile:structuredClone(this.profile),state:structuredClone(this.state)}}
}
