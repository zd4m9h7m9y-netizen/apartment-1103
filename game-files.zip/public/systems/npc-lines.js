// Approved verbatim dialogue from ANN_SAMMY_INTERACTIONS_FOR_REVIEW.md.
export const INTRO={
 ann:{text:'Ann 把书签夹进书里。\n\n「来得正好。我正准备休息一下。」\n「你呢？在认真探索，还是在合理地拖延？」',choices:[['explore','探索。','「好，那我们给它一个正式名称。」'],['delay','合理地拖延。','「诚实。很难反驳。」'],['visit','就来看看你。','「那坐一会儿。书可以等。」']]},
 sammy:{text:'Sammy 把手里的工具放回盒子。\n\n「门没关。进来吧。」\n「如果在找 Bear，先检查你的东西有没有少。」',choices:[['tools','你在忙什么？','「收工具。把它们放回原位，下一次就不用找。」'],['passing','只是路过。','「嗯。想坐就坐。」'],['help','我遇到一点问题。',null]]}
};
export const DAILY={
 ann:[{id:'cup',text:'她把桌上的书挪开一点。\n\n「这里可以放杯子。或者放一本你暂时不想打开的书。」'},{id:'break',text:'Ann 看了一眼书签。\n\n「我决定休息五分钟。至于什么时候开始计时，还可以讨论。」'},{id:'page',text:'她翻过一页，又把书合上。\n\n「刚才那一页可以再读一次。不是它很深奥，是我刚才没在看。」'}],
 sammy:[{id:'tools',text:'Sammy 合上工具箱。\n\n「这盒已经整理好了。希望能保持到明天。」'},{id:'bear',text:'Bear 从她脚边经过。\n\n「他看起来很无辜。我建议保留意见。」'},{id:'wind',text:'她看了一眼窗外。\n\n「外面起风了。上楼之前拿件外套。」'}]
};
export const ROOF_READY={ann:'「找到上去的办法了？」\n「那就去看看。这里的书不会跑。」',sammy:'「R 层亮了。可以上去了。」\n「我们一会儿就到。」'};
export const BIRTHDAY={ann:'「我想了很多种开场白。」Ann 有点不好意思地笑了一下。\n「最后还是觉得……希望你新的一岁，能做喜欢的事，见想见的人。」',sammy:'「灯不会坏，蛋糕也还好。Bear 没偷吃。」\nSammy 停了一秒。\n「生日快乐。我们都在。」'};
const both=(ann,sammy)=>({ann,sammy});
export const ITEM_REACTIONS={
 invite_left:both('「边缘不是装饰。看起来还有另一半。」',null),invite_right:both('「边缘不是装饰。看起来还有另一半。」',null),
 laundry_ticket:both(null,'「上面的编号对应设备。拿好卡，再点那一台。」'),
 invitation:both('「拼好了。现在它是一张邀请，不是两张需要小心保管的纸。」','「去电梯右侧面板试试。不是按门，是用卡。」'),
 postcard_left:both('「先别急着读。它还少了半边城市。」','「另一半不是凭空出现的。看看失物区。」'),postcard_right:both('「先别急着读。它还少了半边城市。」','「另一半不是凭空出现的。看看失物区。」'),
 postcard:both('「正面是风景。背面大概不只是留白。」','「四个窗格，四个输入位置。顺序也要对。」'),
 icon_guide:both('「方向也是信息。别只看见三个图案。」','「先看从哪边开始，再按。省一次重来。」'),
 message_card:both('「图标重复出现，通常不是因为装饰预算不够。」','「试试公共桌旁那个盒子。拿着这张卡去。」'),
 sequence_card:both('「这次顺序已经写得很清楚了。」','「面板上的图标是同一组。按卡上的来。」')
};
export const DISCOVERY_TOPICS=[
 {id:'punisher',npc:'ann',requires:['personal.punisher'],label:'看到那张唱片了。',text:'「嗯，给它留了一个不用翻很久的位置。」'},
 {id:'evermore',npc:'ann',requires:['personal.evermore'],label:'evermore 也在。',text:'「看来今晚不缺歌。缺的是决定先听哪张的人。」'},
 {id:'ribs',npc:'ann',requires:['personal.ribs'],label:'播放器停在 Ribs。',text:'「那就先留在那里。不是每个东西都急着往下翻。」'},
 {id:'economics',npc:'ann',requires:['personal.economics','personal.future'],label:'书桌看起来很忙。',text:'「它可以忙。你可以先休息一下。」'},
 {id:'pomelo',npc:'sammy',requires:['personal.pomelo'],label:'厨房有柚子。',text:'「看到了。碗在旁边。」'},
 {id:'rootshaw',npc:'sammy',requires:['personal.rootshaw'],label:'收藏盒里有两张标签。',text:'Sammy 看了看盒子：「那就把两张都放好。」'},
 {id:'sock',npc:'sammy',requires:['personal.bearBed'],label:'那只袜子……',text:'Sammy 看向 Bear：「问他。」'}
];
export const HINT_LINES={
 'A.music':both('「目录卡上不只有名字。」','「旁边那张卡，和按钮对得上。」'),
 'A.ticket':both('「待办夹里可能有还没做完的事。」','「先确认你拿的是哪台的卡。」'),
 'A.basket':both('「有东西被挡住了。不是所有问题都需要密码。」','「篮子可以挪。人走得到的地方才放得下。」'),
 'A.join':both('「两半能凑成一个完整的意思。」','「拼好以后，拿在手上，再点面板。」'),
 'B.right':both('「失物区的收纳夹值得再看一眼。」','「折叠台旁边。篮子下面。」'),
 'B.code':both('「看看背面，还有窗格的先后。」','「由左至右。数字不要漏。」'),
 'C.book':both('「那张卡先告诉你从哪里读。」','「先看方向，再按图标。」'),
 'C.box':both('「相同的图标，可能在说同一个地方。」','「把留言拿在手上，对盒子使用。」'),
 'C.panel':both('「最后那张卡，不需要再猜一次。」','「按卡上的顺序。不是上一张。」')
};
