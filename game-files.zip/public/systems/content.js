// Production registry. New narrative content remains empty until the owner approves the design.
// Technical fixtures are imported exclusively by systems-lab.html, never by game.js.
export const PRODUCTION_CONTENT=Object.freeze({
 revision:'round2-technical-only',
 items:{},pickups:{},recipes:[],uses:[],mechanisms:{},
 areas:{rooftop:{status:'awaiting-approval'},birthday_party:{status:'awaiting-approval'}}
});
