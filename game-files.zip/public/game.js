import {createNpcDialogue} from './systems/npc-dialogue.js';
import {Adventure} from './systems/adventure.js';
import {createCampaignRound,buildCampaign,RULESET,CHAIN_NAMES} from './systems/campaign.js';
import {PERSONAL_OBJECTS,TV_COLLECTION,RECORD_COLLECTION,patchPersonal} from './systems/personal.js';
import {createInventoryUI} from './systems/inventory-ui.js';
import {createMechanismUI} from './systems/mechanism-ui.js';
import {createEnding} from './ending.js';
import {blocked,feet,overlaps,findPath,distanceToRect,placementValid} from './engine.js';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const canvas=$('#game'),ctx=canvas.getContext('2d',{alpha:false});ctx.imageSmoothingEnabled=false;
const BASE='assets/environment/';const images={},maps={};let manifest,scene,sceneId,frame=0,last=0,near=null,path=[],pending=null,transitionUntil=0,muted=true,audio=null,drag=null,pointerStart=null,toastTimer;
let hovered=null,touchHintTimer,switchingRound=false;
const keys=new Set();const p={x:320,y:338,dir:'down',moving:false};
let saved;try{saved=JSON.parse(localStorage.getItem('apartment1103.v1')||'{}')}catch{saved={}}
const state={flags:{},notes:[],weather:'clear',lights:true,placements:{},...saved};state.flags||={};state.placements||={};
let archive={discoveries:{},endingUnlocked:false};try{archive={...archive,...JSON.parse(localStorage.getItem('apartment1103.archive.v1')||'{}')}}catch{}archive.discoveries||={};if(state.flags.letterRead)archive.endingUnlocked=true;
const continuing=state.round?.ruleset===RULESET;state.legacyEndingAccess=continuing?!!state.legacyEndingAccess:!!(state.flags.party||state.flags.wish||state.flags.birthday||state.flags.letterRead);
if(!continuing){state.round=createCampaignRound();delete state.adventure}
const campaign=buildCampaign(state.round);const adventure=new Adventure(campaign.defs,state.adventure);
function saveArchive(){try{localStorage.setItem('apartment1103.archive.v1',JSON.stringify(archive))}catch{}}
let endingReplay=false;
function save(){if(switchingRound)return;state.adventure=adventure.snapshot();try{localStorage.setItem('apartment1103.v1',JSON.stringify({...state,sceneId,x:p.x,y:p.y}))}catch{}}
const stopInput=()=>{keys.clear();path=[];pending=null;p.moving=false;};
const inventoryUI=createInventoryUI({system:adventure,save,notify:toast,onOpen:stopInput,onClose:()=>{keys.clear();canvas.focus()},onUse:afterItemUse});
const mechanismUI=createMechanismUI({system:adventure,notify:toast,onOpen:stopInput,onClose:()=>{keys.clear();canvas.focus()},onSolved:id=>{if(id.startsWith('roof.')){$('#mechanism-dialog').close();roofFeedback()}}});
adventure.subscribe(()=>{updateJournal();save()});
const npcDialogue=createNpcDialogue({system:adventure,round:state.round,campaign,archive,talk,onInteraction:npc=>{state.flags[npc]=true;save()}});
const ending=createEnding({onOpen:()=>{path=[];pending=null;keys.clear();p.moving=false;drag=null;},onRead:()=>{archive.endingUnlocked=true;saveArchive();if(!endingReplay)flag('letterRead');},onClose:()=>{endingReplay=false;keys.clear();canvas.focus();}});
function loadImage(url){return new Promise((resolve,reject)=>{const im=new Image;im.onload=()=>resolve(im);im.onerror=()=>reject(new Error('素材加载失败：'+url));im.src=url})}
function toast(s){$('#scene-toast').textContent=s;$('#scene-toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#scene-toast').classList.remove('show'),2800)}
function note(s){adventure.clue('legacy-note:'+s,s,'existing-environment');if(!state.notes.includes(s)){state.notes.push(s);if(state.notes.length>20)state.notes.shift()}$('#journal-note').textContent=s;save()}
function flag(id,n){state.flags[id]=true;if(n)note(n);updateJournal();save()}
function updateJournal(){
 const chain=campaign.chain,complete=adventure.state.completed,claimed=adventure.state.claimed;
 const checks=chain==='A'?[complete.includes('mechanism:music.sequence'),claimed.includes('a.pouch'),!!adventure.state.flags.rooftopReady,!!state.flags.birthday]:chain==='B'?[claimed.includes('apartment_4b.drawer.12'),claimed.includes('b.postcard'),!!adventure.state.flags.rooftopReady,!!state.flags.birthday]:[adventure.count('icon_guide')>0,complete.includes('use:open.publicBox'),!!adventure.state.flags.rooftopReady,!!state.flags.birthday];
 const texts=chain==='A'?[['唱片里的收纳格','留意音乐角的目录卡'],['洗衣房的一次取件','取件卡、设备与篮子'],['拼好邀请，去天台','组合后在 R 面板出示'],['留给你的那个夜晚','天台上的生日聚会']]:chain==='B'?[['床头柜的城市夜景','找到明信片的一半'],['洗衣房的另一半','检查收纳夹与篮子'],['读懂背面的窗格','组合明信片，操作 R 面板'],['留给你的那个夜晚','天台上的生日聚会']]:[['公告板上的说明卡','留意图标与阅读方向'],['书架与那个收纳盒','展开留言，找到顺序卡'],['跟着图标去天台','按最终卡片操作 R 面板'],['留给你的那个夜晚','天台上的生日聚会']];
 const n=checks.filter(Boolean).length;$('#progress').textContent=`${n} / 4`;$('#progress-fill').style.width=`${n*25}%`;
 $$('#quests li').forEach((li,i)=>{li.classList.toggle('done',checks[i]);li.querySelector('b').textContent=checks[i]?'✓':'○';const div=li.querySelector('div');div.replaceChildren(document.createTextNode(texts[i][0]));const small=document.createElement('small');small.textContent=texts[i][1];div.append(small)});
 $('#round-label').textContent=`第 ${state.round.number} 轮`;$('#revisit-ending').hidden=!archive.endingUnlocked;
}
function tone(freq=440,duration=.2,volume=.035){if(muted)return;try{audio||=new(window.AudioContext||window.webkitAudioContext)();audio.resume();const o=audio.createOscillator(),g=audio.createGain();o.type='sine';o.frequency.value=freq;g.gain.setValueAtTime(volume,audio.currentTime);g.gain.exponentialRampToValueAtTime(.001,audio.currentTime+duration);o.connect(g);g.connect(audio.destination);o.start();o.stop(audio.currentTime+duration)}catch{}}
let musicTimer;function music(){clearInterval(musicTimer);if(muted||!state.flags.record)return;let n=0;const notes=[261.63,329.63,392,523.25,440,392,329.63,293.66,261.63,329.63,392,493.88,440,349.23,329.63,293.66];musicTimer=setInterval(()=>tone(notes[n++%notes.length],.65,.025),650)}
function talk(who,title,body,actions=[{label:'继续探索',action:()=>{}}]){
 path=[];pending=null;keys.clear();p.moving=false;$('#speaker').textContent=who;$('#dialogue-title').textContent=title;$('#dialogue-text').textContent=body;const area=$('#dialogue-actions');area.replaceChildren();actions.forEach((a,i)=>{const b=document.createElement('button');b.textContent=a.label;b.className=i===actions.length-1?'primary':'';b.onclick=()=>{$('#dialogue').close();a.action?.();canvas.focus()};area.append(b)});if(!$('#dialogue').open)$('#dialogue').showModal();area.querySelector('button:last-child')?.focus();tone(392,.1,.018)
}
function staticCollisions(){return scene.architectureCollisions}
function colliders(except=null){return [...staticCollisions(),...scene.objects.filter(o=>o.collider&&o!==except).map(o=>o.collider),...scene.characters.map(c=>[c.x-7,c.y-6,14,10])]}
function setScene(id,spawn){if(!maps[id])return;if(!areaOpen(id)){if(!scene)id='elevator';else{talk('APARTMENT 1103','天台暂未开放',campaign.hint(adventure,1));return false}}hovered=null;$('#hover-hint').hidden=true;sceneId=id;scene=maps[id];let target=spawn||scene.spawn;if(blocked(...target,colliders())){const route=findPath(scene.spawn,target,colliders());target=route.at(-1)||scene.spawn}p.x=target[0];p.y=target[1];p.dir='down';p.moving=false;path=[];pending=null;drag=null;near=null;transitionUntil=performance.now()+650;$('#scene-title').textContent=scene.title;$('#rooftop-setting').hidden=!['rooftop','birthday_party'].includes(id);save();toast(scene.title);updateMap();return true;}
function transition(id,spawn){tone(293.66,.25,.03);setScene(id,spawn||maps[id]?.spawn)}
const names={'apartment_4b':'Olivia 的公寓','hallway':'公寓走廊','elevator':'电梯','laundry_room':'洗衣房','apartment_4c':'Ann & Sammy','rooftop':'普通天台','birthday_party':'生日天台'};
const routeText={apartment_4b:'从走廊的 1103 门进入 Olivia 的公寓。',hallway:'走近房间上方的门，按 E，或直接点击房门。',elevator:'从走廊右上方进入电梯；在轿厢右侧按钮选择 R 层通往天台。',laundry_room:'从走廊的 LAUNDRY 门进入洗衣房。',apartment_4c:'从走廊的 4C 门进入 Ann 和 Sammy 的公寓。',rooftop:'走廊 → 电梯 → 右侧面板的 R 按钮。',birthday_party:'在天台打开神秘邀请函，选择点亮派对。'};
function updateMap(){$$('#map-layout .map-card').forEach(b=>{b.classList.toggle('current',b.dataset.id===sceneId);b.setAttribute('aria-current',b.dataset.id===sceneId?'location':'false')})}
function getBounds(o){if(o.collider)return o.collider;if(o.character)return[o.x-10,o.y-12,20,14];return [o.x,o.y+o.height-20,o.width,20]}
function range(o){return distanceToRect(p.x,p.y,getBounds(o))}
function nearby(){let best=null,bestD=43;for(const o of interactables()){const d=range(o);if(d<bestD){best=o;bestD=d}}return best}
function interactables(){return [...scene.objects.filter(o=>o.eventId&&objectVisible(o)),...scene.characters.map(c=>({...c,character:true,width:32,height:48}))]}
function doEvent(o,{replay=false}={}){if(!o?.eventId)return;const npc=({ann:'ann',sammy:'sammy',birthday_ann:'ann',birthday_sammy:'sammy'})[o.eventId];if(npc){const item=inventoryUI.held;inventoryUI.clearHeld();npcDialogue.open(npc,{birthday:o.eventId.startsWith('birthday_'),roofReady:areaOpen('rooftop'),item});return;}if(handleCampaign(o))return;if(inventoryUI.held&&!o.eventId.startsWith('travel.')){inventoryUI.use(o.id);return}if(adventure.defs.pickups[o.id]){const result=adventure.pickup(o.id);toast(result.ok?(result.already?'物品已经收好。':'已收入口袋。'):'还不能拿取这件物品。');return}if(o.mechanismId){if(adventure.defs.mechanisms[o.mechanismId]?.type==='drag'){talk('探索','可以挪开这个篮子','走近后按住篮子，把它拖到旁边空地。');}else mechanismUI.open(o.mechanismId);return}const first=adventure.inspect(o.id);if(!first&&!replay&&['ann','sammy','vending','record','drawer'].includes(o.eventId)){talk('探索记录','这处互动已经完成','之前的内容已记录，可以继续探索，或主动回顾。',[{label:'回顾内容',action:()=>doEvent(o,{replay:true})},{label:'继续探索',action:()=>{}}]);return}const e=o.eventId;if(e.startsWith('travel.')){transition(e==='travel.rooftop'&&state.flags.party?'birthday_party':e.slice(7));return}tone(523.25,.1,.02);
 switch(e){
 case 'record':flag('record','那首熟悉的歌，又开始播放了。');music();talk('OLIVIA','A side, B side.','唱针落下，一点细微的沙沙声。\n唱片封套里夹着一张手写便签：「今晚的歌单，请一直听到最后。」');break;
 case 'tv':state.flags.tv=!state.flags.tv;save();talk('OLIVIA',state.flags.tv?'深夜频道':'安静下来',state.flags.tv?'电视里正在播放一部老电影。字幕刚好停在：「最好的地方，是有人等你回家的地方。」':'屏幕暗了下来，只留下窗外的城市灯光。');break;
 case 'fridge':talk('OLIVIA','冰箱上的小纸条','「上层的盒子先别打开。——A」\n旁边又补了一行：「真的别开。——S」\n最下面有一个不太像签名的爪印。');note('冰箱里好像藏着什么。');break;
 case 'books':talk('OLIVIA','借书卡','一本折角的小说里，夹着 Ann 的借书卡。背面写着：「有空来 4C 坐坐。」');break;
 case 'drawer':flag('drawer');talk('OLIVIA','一张旧照片','照片里，三个人和一只狗挤在同一把伞下。照片背面：\n「以后也要一起，过很多个普通的日子。」');note('把这张旧照片，小心收进口袋。');break;
 case 'desk':talk('OLIVIA','尚未写完的一页','摊开的笔记本里有一张小小的清单：买咖啡、还书、给 Bear 买零食。\n最后一行被人悄悄添上：「也别忘了，对自己好一点。」');break;
 case 'bed':talk('OLIVIA','熟悉的房间','被子还保留着阳光晒过的气味。今天先不急着睡，楼里似乎还有一点动静。');break;
 case 'wardrobe':talk('OLIVIA','黑、白、灰','衣服整齐地挂在一起。最顺手的那件外套，已经在身上了。');break;
 case 'tea':talk('OLIVIA','留给你的那杯','杯底还有一点温度。有人刚来过。');break;
 case 'sofa':talk('OLIVIA','歇一小会儿','沙发软软地接住了这个漫长的一天。远处传来城市的声音。\n不赶时间，再坐一会儿也没关系。');break;
 case 'kitchen':talk('OLIVIA','厨房的香气','台面擦得很干净。空气里却有一点香草和黄油的味道。');break;
 case 'box':case 'parcel':talk('OLIVIA','轻拿轻放','箱子上写着「易碎」。试着走近后，按住箱子拖动，可以把它移到旁边。\n收件人那一栏，字迹有些熟悉。');break;
 case 'bell':talk('1103 · DOORBELL','叮咚。','门铃响了两声。屋里静悄悄的——因为你就在这里。\n隔壁传来一声压低的笑。');tone(659,.25);setTimeout(()=>tone(523,.5),200);break;
 case 'notice':talk('BUILDING NOTICE','本周公告','• 洗衣房请及时取走衣物。\n• 电梯 R 层通往天台，晚间开放。\n• 今晚天台有私人聚会。请给某位住户保密。\n\n最后一句，被人用胶带匆匆盖住了一半。');break;
 case 'vending':talk('VENDING MACHINE','一罐温柔的奖励','硬币落下，机器亮了一下。你拿到一罐热可可。\n罐子底下贴着一颗小小的金色星星。');note('口袋里，多了一罐热可可。');break;
 case 'fire':talk('OLIVIA','安全第一','消防器材状态正常。Sammy 大概早就检查过了。');break;
 case 'elevator_panel':talk('ELEVATOR','去哪一层？','11 层是熟悉的公寓。R 层是夜风和星光。',[{label:'11 · 公寓走廊',action:()=>transition('hallway',[565,150])},{label:'R · 天台',action:()=>transition(state.flags.party?'birthday_party':'rooftop',[320,337])}]);break;
 case 'washer':{
  const event=Number(adventure.ambient(o.id,['0','1','2']));flag('laundry','洗衣房的小纸条，指向楼顶的星光。');state.flags['running.'+o.id]=!state.flags['running.'+o.id];
  const texts=['滚筒转了半圈，一张叠好的纸条从衣物间露出来：\n「如果今天有一点特别，就抬头看看。——A」','洗衣机发出轻轻一响。一只落单的袜子旁边，藏着一张星星贴纸。\n贴纸背面写着：「往更高一点的地方走。」','你打开滚筒，发现一个被保护得很好的信封：\n「天台，今晚。别忘了带上你自己。」'];talk('LAUNDRY · RANDOM EVENT','洗衣机里的小发现',texts[event]);break;}
 case 'dryer':state.flags['running.'+o.id]=!state.flags['running.'+o.id];save();talk('OLIVIA','温暖的滚筒','烘干机嗡嗡作响。柔软的毛巾翻了个身，好像也在享受这个夜晚。');break;
 case 'locker':{
  const t=['柜门里贴着一张便签：「备用彩灯，请勿借走。——S」','一个网球滚了出来。远处似乎传来 Bear 的叫声。','柜子里有一袋气球。你决定假装没看见。'];talk('LAUNDRY · RANDOM EVENT','柜门背后',adventure.ambient(o.id,t));break;}
 case 'fold':talk('OLIVIA','叠得整整齐齐','几条毛巾、一件深色夹克，还有一缕干净的皂香。');break;
 case 'basket':talk('OLIVIA','洗衣篮','篮子不重，可以拖到别的地方。里面藏着一只不属于你的袜子。');break;
 case 'supplies':talk('OLIVIA','清洁用品架','洗衣液、夹子、备用灯泡。每样东西都贴好了标签。');break;
 case 'lost':talk('LOST & FOUND','失物招领','一把伞、一本书、三个夹子。\n公告写着：「如果捡到一颗期待的心，请送到天台。」\n字迹像 Ann。');break;
 case 'ann':flag('ann','Ann 说，今晚的风景值得上楼看看。');talk('ANN','你来得正好。','「我正想找你。」Ann 合上书，推了推黑色圆框眼镜。\n「今天过得怎么样？如果还不够好，晚一点……也许会好起来。」\n她朝电梯的方向看了一眼。',[{label:'你们在忙什么？',action:()=>talk('ANN','一点小事。','「Sammy 在检查灯。我在……整理一些照片。」\n她停顿了一下。\n「总之，去天台走走吧。我们随后就到。」')},{label:'好，待会儿见。',action:()=>{}}]);break;
 case 'sammy':flag('sammy');talk('SAMMY','晚点上楼。','Sammy 把工具放回原位。\n「天台的灯修好了。风不大，适合待一会儿。」\n她看了看你，又补了一句：「带件外套。」');break;
 case 'bear':tone(147,.13,.035);talk('BEAR','汪！','Bear 的尾巴摇个不停。他嗅了嗅你的口袋，又跑向门口，回头等你。\n他似乎早就知道，今晚会发生什么。');break;
 case 'ann_books':talk('ANN’S CORNER','被认真收藏的句子','书页间满是细小的标记。其中一句被圈了起来：\n「愿你在爱里，成为你自己。」');break;
 case 'ann_notes':talk('ANN’S CORNER','一份过于详细的计划','时间、灯光、歌单、蛋糕……最后一项写着：\n「确保 Olivia 开心。」\n旁边画着一颗小小的星星。');note('Ann 的计划，似乎与你有关。');break;
 case 'sammy_tools':talk('SAMMY’S CORNER','每一件都有位置','螺丝刀、钳子、绝缘胶带整齐地摆在工具架上。\n空出的那一格，形状像一卷彩灯。');break;
 case 'toolbox':talk('SAMMY’S CORNER','结实的工具箱','箱盖上有细小的划痕。搭扣牢牢扣着，可以把工具箱拖到旁边。');break;
 case 'sammy_hidden':flag('hidden');talk('SAMMY’S CORNER','藏得并不深的温柔','收纳柜最里面，是一小袋 Bear 喜欢的零食。\n旁边压着一张便签：「别让他一次吃完。」\n字写得很小。');note('发现了 Sammy 和 Bear 之间的小秘密。');break;
 case 'guitar':talk('OLIVIA','不太常听见的歌','琴弦调得很准。琴盒里藏着一张手写歌单，第一首旁边标着「她喜欢」。');break;
 case 'bear_bed':talk('OLIVIA','Bear 的领地','窝里有一只网球、一块毯子，还有一只失踪的拖鞋。');break;
 case 'garden':talk('ROOFTOP GARDEN','一点点绿意','叶片在夜风里轻轻晃动。城市这么大，这里却很安静。');break;
 case 'rooftop_table':talk('OLIVIA','城市之上','灯光越过街区，像一片缓慢流动的星海。桌上有三个杯子，还有一只给 Bear 的碗。');break;
 case 'party_prepare':talk('TO OLIVIA','请在这里，停留片刻。','「我们想把这个平常的夜晚，变成一个你会记得的夜晚。\n准备好了吗？」',[{label:'再看看夜景',action:()=>{}},{label:'点亮今晚 ✦',action:()=>{flag('party');transition('birthday_party',[320,337]);tone(523,.5);setTimeout(()=>tone(659,.5),300);setTimeout(()=>tone(784,.8),600);}}]);break;
 case 'birthday_ann':talk('ANN','生日快乐，Olivia。','「我想了很多种开场白。」Ann 有点不好意思地笑了一下。\n「最后还是觉得……希望你新的一岁，能做喜欢的事，见想见的人。」');break;
 case 'birthday_sammy':talk('SAMMY','都准备好了。','「灯不会坏，蛋糕也还好。Bear 没偷吃。」\nSammy 停了一秒。\n「生日快乐。我们都在。」');break;
 case 'final_letter':if(!state.flags.wish){talk('TO OLIVIA','还有最后一份礼物。','先在蛋糕前许个愿吧。这个盒子，是留给那之后的。',[{label:'去许愿',action:()=>doEvent(scene.objects.find(o=>o.eventId==='birthday'))}]);}else ending.open();break;
 case 'gift':talk('FROM ANN','一本属于你的书','礼物里是一本空白手账。扉页上写着：\n「把值得记住的日子，慢慢写满吧。我们还有很多页。」');break;
 case 'gift_sammy':talk('FROM SAMMY','一份实用的浪漫','一盏小小的随身灯，和一张字迹简短的卡片：\n「夜路用得上。需要的时候，叫我。」');break;
 case 'photos':talk('OUR LITTLE MOMENTS','原来，已经有这么多回忆。','沙发上的午后、雨里的街角、Bear 偷走袜子的瞬间。\n没有哪一张足够完美，但每一张都值得留下。');break;
 case 'birthday':flag('birthday','生日快乐。愿每一次回家，都有人等你。');talk('ANN, SAMMY & BEAR','Happy birthday, Olivia.','烛光亮着，熟悉的人就在身边。\n\n愿你新的一岁，有勇气奔向喜欢的生活，也总有一个温暖的地方，可以安心回来。\n\nApartment 1103，永远为你留一盏灯。'+(state.flags.drawer&&state.flags.hidden?'\n\n✦ 你找到了藏起来的温柔。原来，爱一直都在小事里。':''),[{label:'许下愿望 ✦',action:()=>{state.flags.wish=true;save();toast('✦ 愿望已收好。还有一个礼物盒，留在天台。');for(let i=0;i<8;i++)setTimeout(()=>tone([523,587,659,784][i%4],.4,.04),i*180)}}]);break;
 default:talk('OLIVIA','一个小小的细节','这个地方，被人认真照顾着。');
 }
}

function objectCompleted(o){return adventure.state.inspected.includes(o.id)||adventure.state.claimed.includes(o.id)||(o.mechanismId&&adventure.state.completed.includes('mechanism:'+o.mechanismId))}
function discover(id,title,kind){if(!archive.discoveries[id]){archive.discoveries[id]={title,kind};saveArchive()}adventure.inspect(id)}
function afterItemUse({item,target,result}){
 if(!result.ok)return;
 const obj=maps.elevator?.objects.find(o=>o.eventId==='elevator_panel');
 if(target===obj?.id){if(adventure.state.flags.rooftopReady){roofFeedback()}else if(obj.mechanismId)mechanismUI.open(obj.mechanismId)}
 if(target==='c.publicBox')toast('盒子打开了。最终顺序卡已收入口袋。');
}
function roofFeedback(){tone(659,.3,.03);talk('R · ACCESS','天台已经开放','面板上的指示灯亮了起来。',[{label:'去天台',action:()=>transition(state.flags.party?'birthday_party':'rooftop',[320,337])}])}
function handleCampaign(o){
 if(o.eventId==='personal.inspect'){
  const show=()=>{discover(o.id,o.title,o.kind);talk(o.kind,o.title,o.text)};
  if(o.hiddenReveal&&!archive.discoveries[o.id])talk('探索','薄薄的收藏盒','封面后面还有一层内页。',[{label:'先放回去',action:()=>{}},{label:'打开内页',action:show}]);else show();return true;
 }
 if(o.id==='music.directory'){adventure.clue('music.directory',campaign.descriptions[o.id]);talk('音乐角','收纳目录',campaign.descriptions[o.id]);return true}
 if(o.id==='c.publicBox'&&!inventoryUI.held){talk('探索','公共桌旁的收纳盒',adventure.state.completed.includes('use:open.publicBox')?'盒子已经打开，顺序卡已经收好。':'盒面上的图标和展开的留言卡很像。可以拿好卡片，再点击这里。');return true}
 if(o.description&&!inventoryUI.held){adventure.clue(o.id,o.description);talk('探索',o.label,o.description);return true}
 if(o.eventId==='elevator_panel'&&!inventoryUI.held){
  if(areaOpen('rooftop')){talk('ELEVATOR','去哪一层？','R 层的指示灯已经亮起。',[{label:'11 · 走廊',action:()=>transition('hallway',[565,147])},{label:'R · 天台',action:()=>transition(state.flags.party?'birthday_party':'rooftop',[320,337])}]);return true}
  if(o.mechanismId){mechanismUI.open(o.mechanismId);return true}
  talk('R · 暂未开放','还有一份邀请',campaign.hint(adventure,1));return true;
 }
 if(campaign.chain==='A'&&o.eventId==='washer'&&!inventoryUI.held){talk('LAUNDRY',`洗衣机 ${Number(o.id.split('.').at(-1))+1} 号`,adventure.state.flags.laundryReleased?'取件已经确认，看看折叠台旁的篮子。':'设备的取件槽需要对应的取件卡。');return true}
 if(o.eventId==='record'&&!o.mechanismId&&!inventoryUI.held){flag('record');music();discover('personal.musicDirectory','音乐收藏目录','音乐收藏');talk('音乐收藏','A side, B side.',RECORD_COLLECTION);return true}
 if(o.eventId==='tv'&&!inventoryUI.held){discover('personal.tv','影视收藏列表','影视收藏');talk('电视收藏','休息一会儿',TV_COLLECTION,[{label:state.flags.tv?'关闭电视':'打开电视',action:()=>{state.flags.tv=!state.flags.tv;save()}},{label:'继续探索',action:()=>{}}]);return true}
 if(o.eventId==='desk'&&!inventoryUI.held){discover('personal.future','Economics / 2027 Fall · UK','学习桌');talk('学习桌','正在准备的下一页','A-Level · Economics\n2027 Fall · UK\n复习资料、申请文件夹和日常文具收在同一张桌上。');return true}
 if(o.eventId==='bear_bed'&&!inventoryUI.held){discover('personal.bearBed','Bear 的窝和那只袜子','生活小物');return false}
 return false;
}
function showHint(){talk('OLIVIA’S JOURNAL','一点提示',campaign.hint(adventure,1),[{label:'再具体一点',action:()=>talk('OLIVIA’S JOURNAL','下一步可以这样做',campaign.hint(adventure,2))},{label:'我再找找',action:()=>{}}])}
function openArchive(){const area=$('#archive-list');area.replaceChildren();for(const {title,kind}of Object.values(archive.discoveries)){const p=document.createElement('p');p.textContent=`${kind} · ${title}`;area.append(p)}if(!Object.keys(archive.discoveries).length)area.textContent='还没有发现收藏。慢慢看看那些不起眼的角落。';$('#archive-ending').hidden=!archive.endingUnlocked;$('#archive-dialog').showModal()}
function replayEnding(){for(const d of $$('dialog'))if(d.open)d.close();endingReplay=true;ending.open()}
function startNewRound(){
 const next=createCampaignRound(state.round);saveArchive();switchingRound=true;try{localStorage.setItem('apartment1103.previous-round.v1',JSON.stringify({...state,adventure:adventure.snapshot(),sceneId,x:p.x,y:p.y}));localStorage.setItem('apartment1103.v1',JSON.stringify({round:next,flags:{},notes:[],weather:state.weather,lights:state.lights,placements:{},legacyEndingAccess:false,sceneId:'apartment_4b',x:320,y:338}))}catch{switchingRound=false;toast('未能保存新一轮，请检查浏览器存储后重试。');return}location.reload();
}
function confirmNewRound(){for(const d of $$('dialog'))if(d.open)d.close();talk('APARTMENT 1103','开始新一轮探索？','本轮物品、谜题和天台进度会重新开始。已发现的收藏和已经解锁的信件／合照回顾会保留。',[{label:'继续当前一轮',action:()=>{}},{label:'开始新一轮',action:startNewRound}])}
$('#new-round').onclick=confirmNewRound;$('#story-hint').onclick=showHint;$('#archive-open').onclick=openArchive;$('#archive-close').onclick=()=>$('#archive-dialog').close();$('#archive-ending').onclick=$('#revisit-ending').onclick=replayEnding;

function areaOpen(id){
 // Completed pre-round-2 endings retain replay access; this is save migration, not a new story condition.
 if(['rooftop','birthday_party'].includes(id)&&state.legacyEndingAccess)return true;
 const status=adventure.areaStatus(id);if(status.open)return true;if(status.ready){return adventure.unlockArea(id).ok}return false;
}
function objectVisible(o){return o.container||!adventure.defs.pickups[o.id]||adventure.visiblePickup(o.id)}
function hitObject(x,y){return interactables().reverse().find(o=>o.character?Math.abs(x-o.x)<16&&y>=o.y-45&&y<o.y+6:x>=o.x&&x<o.x+o.width&&y>=o.y&&y<o.y+o.height)}
function showHover(c){hovered=hitObject(c.x,c.y);canvas.style.cursor=hovered?'pointer':'crosshair';const tip=$('#hover-hint');tip.hidden=!hovered;tip.textContent=hovered?`${hovered.label}${objectCompleted(hovered)?' · 已查看':''}`:'';tip.style.left=`${Math.min(c.x/640*100,62)}%`;tip.style.top=`${Math.min(c.y/400*100+5,85)}%`;}
function modalOpen(){return $$('dialog').some(d=>d.open)}
function act(){if(modalOpen())return;const o=nearby();if(o)doEvent(o);else toast('走近带有 ◇ 标记的物品，再按 E。')}
function walkTo(x,y,obj){path=findPath([p.x,p.y],[x,y],colliders());pending=obj||null;if(obj&&range(obj)<43){path=[];doEvent(obj)}else if(!path.length&&!obj)toast('这里暂时走不过去。')}
function approach(o){const r=getBounds(o),candidates=[[r[0]+r[2]/2,r[1]+r[3]+18],[r[0]-16,r[1]+r[3]/2],[r[0]+r[2]+16,r[1]+r[3]/2],[r[0]+r[2]/2,r[1]-16]];let best=null,bestCost=Infinity;
 for(const [x,y]of candidates){if(blocked(x,y,colliders()))continue;const q=findPath([p.x,p.y],[x,y],colliders());const end=q.at(-1)||[p.x,p.y];if(distanceToRect(...end,r)>42)continue;const cost=q.length;if(cost<bestCost){best=q;bestCost=cost}}if(best){path=best;pending=o;if(!path.length){doEvent(o);pending=null}}else toast('试着从另一边靠近。');
}
function point(ev){const r=canvas.getBoundingClientRect();return {x:(ev.clientX-r.left)*640/r.width,y:(ev.clientY-r.top)*400/r.height}}
canvas.addEventListener('pointerdown',ev=>{if(modalOpen())return;canvas.focus();const c=point(ev);if(ev.pointerType==='touch'){showHover(c);clearTimeout(touchHintTimer);touchHintTimer=setTimeout(()=>{hovered=null;$('#hover-hint').hidden=true},1400)}pointerStart={...c,id:ev.pointerId};const o=[...scene.objects].reverse().find(o=>o.draggable&&c.x>=o.x&&c.x<o.x+o.width&&c.y>=o.y&&c.y<o.y+o.height&&range(o)<55);if(o){drag={o,start:{x:o.x,y:o.y,collider:[...o.collider]},offset:{x:c.x-o.x,y:c.y-o.y},moved:false};canvas.setPointerCapture(ev.pointerId);path=[];pending=null;}});
canvas.addEventListener('pointermove',ev=>{const c=point(ev);if(!drag){showHover(point(ev));return}const o=drag.o,nx=Math.round((c.x-drag.offset.x)/8)*8,ny=Math.round((c.y-drag.offset.y)/8)*8,dx=nx-o.x,dy=ny-o.y;if(Math.hypot(c.x-pointerStart.x,c.y-pointerStart.y)>4)drag.moved=true;if(!drag.moved)return;const rc=[o.collider[0]+dx,o.collider[1]+dy,o.collider[2],o.collider[3]];if(nx<16||ny<80||nx+o.width>624||ny+o.height>384)return;if(placementValid(rc,colliders(o),p,scene.exits)){o.x=nx;o.y=ny;o.collider=rc;}});
canvas.addEventListener('pointerup',ev=>{const c=point(ev);if(!pointerStart)return;if(drag?.moved){state.placements[drag.o.id]={x:drag.o.x,y:drag.o.y};if(drag.o.mechanismId){const result=adventure.operate(drag.o.mechanismId,{x:drag.o.x,y:drag.o.y,valid:true});if(result.ok)toast('机关状态已保存。')}save();toast('已放好 · 位置会自动保存');drag=null;pointerStart=null;return}drag=null;pointerStart=null;if(modalOpen())return;const hit=interactables().reverse().find(o=>o.character?Math.abs(c.x-o.x)<16&&c.y>=o.y-45&&c.y<o.y+6:c.x>=o.x&&c.x<o.x+o.width&&c.y>=o.y&&c.y<o.y+o.height);if(hit)approach(hit);else walkTo(c.x,c.y);});
canvas.addEventListener('pointerleave',()=>{hovered=null;$('#hover-hint').hidden=true});
canvas.addEventListener('pointercancel',()=>{drag=null;pointerStart=null});
const motionKeys=['w','a','s','d','arrowup','arrowdown','arrowleft','arrowright'];window.addEventListener('keydown',ev=>{const k=ev.key.toLowerCase();if(modalOpen()){if(k==='enter'&&$('#dialogue').open){ev.preventDefault();$('#dialogue-actions button:last-child')?.click()}return}if(motionKeys.includes(k)){ev.preventDefault();keys.add(k);path=[];pending=null;}else if(k==='e'||k===' '){ev.preventDefault();if(!ev.repeat)act()}else if(k==='i'){inventoryUI.open()}else if(k==='m'){$('#map-modal').showModal()}});window.addEventListener('keyup',ev=>keys.delete(ev.key.toLowerCase()));window.addEventListener('blur',()=>{keys.clear();p.moving=false});document.addEventListener('visibilitychange',()=>{if(document.hidden){keys.clear();save()}});
$$('[data-dir]').forEach(b=>{const key={up:'arrowup',down:'arrowdown',left:'arrowleft',right:'arrowright'}[b.dataset.dir];b.onpointerdown=ev=>{ev.preventDefault();b.setPointerCapture(ev.pointerId);keys.add(key);path=[];pending=null};b.onpointerup=b.onpointercancel=()=>keys.delete(key)});$('#touch-interact').onclick=act;
$('#sound').onclick=()=>{muted=!muted;$('#sound span').textContent=muted?'声音关':'声音开';$('#sound').setAttribute('aria-pressed',String(!muted));tone(523,.2);music()};$('#light').onclick=()=>{state.lights=!state.lights;updateSettings();save()};function updateSettings(){$('#light').setAttribute('aria-pressed',String(state.lights));$('#light').firstChild.textContent=state.lights?'暖灯已开 ':'暖灯已关 ';$$('[data-weather]').forEach(b=>b.classList.toggle('selected',b.dataset.weather===state.weather));$('#weather-label').textContent={clear:'☾ 晴朗的夜晚',rain:'☂ 城市里的细雨',snow:'❄ 今晚有雪'}[state.weather]};$$('[data-weather]').forEach(b=>b.onclick=()=>{state.weather=b.dataset.weather;updateSettings();save()});
$('#help').onclick=()=>$('#help-modal').showModal();$('#close-help').onclick=$('#resume').onclick=()=>{$('#help-modal').close();canvas.focus()};$('#map-button').onclick=()=>$('#map-modal').showModal();$('#close-map').onclick=()=>{$('#map-modal').close();canvas.focus()};$('#reset').onclick=()=>{$('#help-modal').close();talk('APARTMENT 1103','重新开始？','这会清除本浏览器中的故事进度和物品位置。',[{label:'保留当前故事',action:()=>{}},{label:'重新开始',action:()=>{localStorage.removeItem('apartment1103.v1');location.reload()}}])};$('#fullscreen').onclick=()=>{const w=$('#canvas-wrap');if(document.fullscreenElement)document.exitFullscreen?.();else w.requestFullscreen?.().catch(()=>toast('此浏览器暂不支持全屏，可尝试横屏。'))};$('#party-toggle').onclick=()=>{const party=sceneId==='rooftop';if(party)flag('party');setScene(party?'birthday_party':'rooftop',[320,337])};
// Pixel scene renderer. Furniture is depth-sorted independently from architecture.
function sprite(o){const a=manifest.assets[o.asset],im=images[o.asset],anim=images[o.asset+'.animation'];if(!a||!im)return;const active=o.asset==='cake'||o.asset==='balloons'||(o.asset==='record_player'&&state.flags.record)||(o.asset==='tv'&&state.flags.tv)||state.flags['running.'+o.id];if(anim&&active){const f=Math.floor(frame*a.animation.fps)%4;ctx.drawImage(anim,f*a.width,0,a.width,a.height,Math.round(o.x),Math.round(o.y),a.width,a.height)}else ctx.drawImage(im,Math.round(o.x),Math.round(o.y))}
function character(name,x,y,dir='down',moving=false){const sheet=images['char.'+name];if(!sheet)return;const row=moving?{down:1,up:2,left:3,right:4}[dir]:{down:0,up:2,left:3,right:4}[dir];const f=moving?Math.floor(frame*7)%4:Math.floor(frame*.8)%4;ctx.fillStyle='#171b1744';ctx.beginPath();ctx.ellipse(Math.round(x),Math.round(y)-1,10,3,0,0,Math.PI*2);ctx.fill();ctx.drawImage(sheet,f*32,row*48,32,48,Math.round(x)-16,Math.round(y)-46,32,48)}
function marker(o,selected=false){const x=Math.round(o.character?o.x:o.x+o.width/2),y=Math.round(o.character?o.y-51:o.y-5)+Math.round(Math.sin(frame*2+x)*1);ctx.fillStyle=selected?'#ffe4aa':objectCompleted(o)?'#8f9d7a':'#dfc28b';ctx.globalAlpha=selected?1:.68;ctx.beginPath();ctx.moveTo(x,y-3);ctx.lineTo(x+3,y);ctx.lineTo(x,y+3);ctx.lineTo(x-3,y);ctx.closePath();ctx.fill();ctx.globalAlpha=1}
function draw(){ctx.imageSmoothingEnabled=false;ctx.drawImage(images['bg.'+sceneId],0,0);for(const o of scene.objects.filter(o=>objectVisible(o)&&(o.layer==='floor'||o.layer==='wall')))sprite(o);
 const list=scene.objects.filter(o=>objectVisible(o)&&o.layer==='world').map(o=>({depth:o.depth??o.y+o.height,draw:()=>sprite(o)}));for(const c of scene.characters)list.push({depth:c.y+2,draw:()=>character(c.id,c.x,c.y)});list.push({depth:p.y+2,draw:()=>character('olivia',p.x,p.y,p.dir,p.moving)});list.sort((a,b)=>a.depth-b.depth).forEach(a=>a.draw());
 if(sceneId==='elevator'){const panel=scene.objects.find(o=>o.eventId==='elevator_panel');ctx.fillStyle=areaOpen('rooftop')?'#d6d990':'#786e50';ctx.fillRect(panel.x+22,panel.y+31,4,4)}
 if(state.lights){for(const [x,y,c]of scene.lights)ctx.drawImage(images['light.'+c],x-64,y-64)}else{ctx.fillStyle='#101c3066';ctx.fillRect(0,0,640,400);for(const [x,y,c]of scene.lights)if(c==='cool')ctx.drawImage(images['light.cool'],x-64,y-64)}
 // Weather is outside the windows indoors; across the rooftop outdoors.
 if(state.weather!=='clear'){ctx.save();const roof=sceneId==='rooftop'||sceneId==='birthday_party';if(!roof){ctx.beginPath();for(const o of scene.objects.filter(o=>o.asset==='window'))ctx.rect(o.x+8,o.y+3,o.width-16,o.height-8);ctx.clip()}ctx.strokeStyle=state.weather==='rain'?'#b4ccd877':'#e9e6d3bb';ctx.fillStyle='#ede6ccaa';for(let i=0;i<65;i++){const x=((i*83+(state.weather==='rain'?frame*42:Math.sin(frame+i)*7))%640+640)%640;const y=(i*47+frame*(state.weather==='rain'?150:18))%400;if(state.weather==='rain'){ctx.beginPath();ctx.moveTo(Math.round(x),Math.round(y));ctx.lineTo(Math.round(x-3),Math.round(y+8));ctx.stroke()}else ctx.fillRect(Math.round(x),Math.round(y),2,2)}ctx.restore()}
 if(path.length){const dest=path.at(-1);ctx.strokeStyle='#f1d7a096';ctx.strokeRect(dest[0]-3,dest[1]-3,6,6)}
 for(const o of interactables())marker(o,near?.id===o.id||hovered?.id===o.id||pending?.id===o.id);if(hovered){ctx.strokeStyle='#e7cc92aa';const r=hovered.character?[hovered.x-16,hovered.y-46,32,48]:[hovered.x,hovered.y,hovered.width,hovered.height];ctx.strokeRect(...r);}if(drag){ctx.strokeStyle='#e4cfa2';ctx.strokeRect(drag.o.x,drag.o.y,drag.o.width,drag.o.height)}
 if(state.flags.wish&&sceneId==='birthday_party'){for(let i=0;i<24;i++){ctx.fillStyle=['#e7c685','#a6b68c','#c39078'][i%3];ctx.fillRect((i*73+Math.sin(frame+i)*9)%640,(i*41+frame*13)%400,2,3)}}
 if(performance.now()<transitionUntil){const a=(transitionUntil-performance.now())/650;ctx.fillStyle=`rgba(20,24,20,${Math.max(0,a*.7)})`;ctx.fillRect(0,0,640,400)}
}
function tick(time){const dt=Math.min((time-last)/1000,.04);last=time;frame+=dt;if(!modalOpen()&&!drag){let dx=0,dy=0;if(keys.has('w')||keys.has('arrowup'))dy--;if(keys.has('s')||keys.has('arrowdown'))dy++;if(keys.has('a')||keys.has('arrowleft'))dx--;if(keys.has('d')||keys.has('arrowright'))dx++;let amount=dt*82;
 if(!dx&&!dy&&path.length){const t=path[0],vx=t[0]-p.x,vy=t[1]-p.y,dist=Math.hypot(vx,vy);if(dist<=amount){dx=vx;dy=vy;amount=1;path.shift()}else{dx=vx/dist;dy=vy/dist}}
 else if(dx&&dy){dx/=Math.SQRT2;dy/=Math.SQRT2}
 p.moving=!!(dx||dy);if(p.moving){p.dir=Math.abs(dx)>Math.abs(dy)?(dx>0?'right':'left'):(dy>0?'down':'up');const c=colliders();let moved=false;if(!blocked(p.x+dx*amount,p.y,c)){p.x+=dx*amount;moved=true}if(!blocked(p.x,p.y+dy*amount,c)){p.y+=dy*amount;moved=true}if(!moved&&path.length){path=[];pending=null}}
 if(!path.length&&pending){const o=pending;pending=null;if(range(o)<46)doEvent(o);else toast('再靠近一点，就能互动。')}
 if(time>transitionUntil+300)for(const e of scene.exits){if(overlaps(feet(p.x,p.y),e.rect)){let target=e.target;if(target==='rooftop'&&state.flags.party)target='birthday_party';transition(target,e.spawn);break}}
 near=nearby();const hint=$('#interaction-hint');hint.style.display=near?'block':'none';hint.textContent=near?`E · ${near.label}${near.draggable?' · 按住拖动':''}`:'';
 }else p.moving=false;draw();requestAnimationFrame(tick)}
async function init(){try{manifest=await fetch(BASE+'manifest.json').then(r=>{if(!r.ok)throw new Error('Manifest');return r.json()});await Promise.all(manifest.scenes.map(async s=>{const m=await fetch(BASE+s.map).then(r=>r.json());const originals=new Set(m.objects.filter(o=>o.collider).map(o=>JSON.stringify(o.collider)));m.architectureCollisions=m.collisions.filter(c=>!originals.has(JSON.stringify(c)));maps[s.id]=m;images['bg.'+s.id]=await loadImage(BASE+m.background);for(const o of m.objects){const pos=state.placements[o.id];if(pos&&o.draggable){const dx=pos.x-o.x,dy=pos.y-o.y;o.x=pos.x;o.y=pos.y;o.collider=[o.collider[0]+dx,o.collider[1]+dy,...o.collider.slice(2)]}}}));
 campaign.patch(maps);patchPersonal(maps);
 await Promise.all(Object.entries(manifest.assets).map(async([name,a])=>{images[name]=await loadImage(BASE+a.path);if(a.animation)images[name+'.animation']=await loadImage(BASE+a.animation.path)}));await Promise.all(['olivia','ann','sammy','bear'].map(async name=>images['char.'+name]=await loadImage(`assets/characters/${name}.png`)));for(const c of ['warm','cool'])images['light.'+c]=await loadImage(BASE+`lighting_fx/${c}.png`);
 const mapArea=$('#map-layout');for(const s of manifest.scenes){if(s.id==='birthday_party')continue;const b=document.createElement('button');b.className='map-card';b.dataset.id=s.id;const im=new Image;im.src=BASE+s.id+'/preview.png';im.alt=names[s.id];const label=document.createElement('span');label.textContent=names[s.id]+(s.id==='rooftop'&&!areaOpen('rooftop')?' · 暂未开放':'');b.append(im,label);b.onclick=()=>{$('#map-modal').close();talk('APARTMENT MAP',names[s.id],routeText[s.id])};mapArea.append(b)}
 setScene(maps[saved.sceneId]?saved.sceneId:'apartment_4b',saved.x!==undefined?[saved.x,saved.y]:undefined);updateSettings();updateJournal();inventoryUI.render();if(state.notes.length)$('#journal-note').textContent=state.notes.at(-1);$('#loading').remove();last=performance.now();requestAnimationFrame(tick);setInterval(save,5000);
 window.Apartment1103={state,maps,manifest,player:p,get scene(){return scene},get sceneId(){return sceneId},colliders,interact:doEvent,travel:setScene,findPath:(x,y)=>findPath([p.x,p.y],[x,y],colliders()),ending,adventure,inventoryUI,campaign,archive,npcDialogue,newRound:startNewRound,get path(){return path},get pending(){return pending}};
 }catch(e){console.error(e);$('#loading').textContent='未能打开公寓，请刷新重试。'+e.message}}
$('#reset').onclick=confirmNewRound;
init();
