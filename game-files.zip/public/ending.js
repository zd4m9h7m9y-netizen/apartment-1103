// The author's letter is stored verbatim. Do not normalize punctuation or rewrite it.
export const LETTER_PARAGRAPHS = Object.freeze([
  'Hey Olivia,',
  'Happy 17th birthday!',
  'Probably this might be the weirdest birthday present you have ever received but hope you enjoyed this small world. It may be not perfect cuz this is my first vibecoding, but I really tried.',
  'I really appreciate having you in my life and I know that this might be the last school year we’re being together, so I made this little game all about you and also included me as a main character :P',
  'Thanks 4 being my friend and wish you a lucky semester ahead.',
  'Love from Anna'
]);
export const LETTER_TEXT = LETTER_PARAGRAPHS.join('\n\n');
export const BIRTHDAY = Object.freeze({name:'Olivia',birthDate:'2009-11-03',celebrationDate:'2026-11-03',age:17});

export function createEnding({onOpen=()=>{},onRead=()=>{},onClose=()=>{}}={}) {
  const dialog=document.querySelector('#ending'),paper=document.querySelector('#letter-paper'),body=document.querySelector('#letter-body'),next=document.querySelector('#letter-next'),progress=document.querySelector('#letter-progress'),photo=document.querySelector('#keepsake'),image=document.querySelector('#keepsake-image');
  const reduced=()=>window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  let count=0,phase='closed',timer=null;
  function render(){
    body.replaceChildren(...LETTER_PARAGRAPHS.slice(0,count).map((text,i)=>{const p=document.createElement('p');p.textContent=text;if(i===count-1)p.className='letter-new';return p}));
    progress.textContent=`${count} / ${LETTER_PARAGRAPHS.length}`;
    next.textContent=count===LETTER_PARAGRAPHS.length?'收好这封信 →':'继续阅读 →';
    const newest=body.lastElementChild;
    if(newest)requestAnimationFrame(()=>newest.scrollIntoView({block:'nearest',behavior:reduced()?'instant':'smooth'}));
  }
  function advance(){if(phase!=='letter')return;if(count<LETTER_PARAGRAPHS.length){count++;render();return}showPhoto()}
  function showPhoto(){
    if(phase!=='letter')return;phase='transition';next.disabled=true;paper.classList.add('letter-leaving');onRead();
    timer=setTimeout(()=>{paper.hidden=true;photo.hidden=false;phase='photo';dialog.dataset.phase='photo';document.querySelector('#photo-return').focus();},reduced()?0:900);
  }
  function open(){clearTimeout(timer);count=1;phase='letter';paper.hidden=false;photo.hidden=true;next.disabled=false;paper.classList.remove('letter-leaving');dialog.dataset.phase='letter';render();onOpen();if(!dialog.open)dialog.showModal();next.focus();}
  function close(){clearTimeout(timer);dialog.close();phase='closed';onClose();}
  next.addEventListener('click',e=>{e.stopPropagation();advance()});
  paper.addEventListener('click',e=>{if(e.target.closest('button,a')||window.getSelection()?.toString())return;advance()});
  dialog.addEventListener('keydown',e=>{
    if(phase==='letter'&&['Enter',' ','ArrowRight'].includes(e.key)){e.preventDefault();e.stopPropagation();if(!e.repeat)advance()}
  });
  dialog.addEventListener('cancel',e=>{e.preventDefault();if(phase!=='transition')close()});
  document.querySelector('#letter-later').addEventListener('click',close);
  document.querySelector('#photo-return').addEventListener('click',close);
  document.querySelector('#photo-reread').addEventListener('click',open);
  // Preload without displaying the photo while the letter is open.
  image.src='assets/ending/ann-olivia-keepsake.png';
  return {open,close,get phase(){return phase},get revealedCount(){return count}};
}
